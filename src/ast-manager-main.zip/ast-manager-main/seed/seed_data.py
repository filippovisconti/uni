import requests
from faker import Faker
import random
from datetime import datetime

API_BASE = "https://localhost:7019/api"
faker = Faker("it_IT")

NUM_ENTRIES = 50

company_ids = []
user_ids = []
project_ids = []
letter_ids = []


def create_company():
    data = {
        "name": faker.company(),
        "contactEmail": faker.company_email(),
        "contactPhone": f"+39{faker.random_number(digits=10, fix_len=True)}",
        "address": {
            "street": faker.street_name(),
            "houseNumber": faker.building_number(),
            "city": faker.city(),
            "province": faker.state(),
            "postalCode": faker.postcode(),
            "country": faker.country(),
        },
    }
    response = requests.post(f"{API_BASE}/companies", json=data, verify=False)
    # print(response.text)
    return response.json()["id"]


def create_user():
    data = {
        "firstName": faker.first_name(),
        "lastName": faker.last_name(),
        "nickname": faker.user_name(),
    }
    response = requests.post(f"{API_BASE}/users", json=data, verify=False)
    return response.json()["id"]


def create_project():
    data = {"name": faker.bs().title(), "description": faker.text(max_nb_chars=200)}
    response = requests.post(f"{API_BASE}/projects", json=data, verify=False)
    return response.json()["id"]


def create_letter():
    data = {
        "protocolNumber": f"LT-{faker.random_number(digits=5)}",
        "subject": faker.sentence(nb_words=5),
        "body": faker.text(max_nb_chars=200),
        "senderProtocolNumber": f"SP-{faker.random_number(digits=5)}",
        "senderProtocolDate": f"{faker.date_between_dates(date_start=datetime(2019, 1, 1), date_end=datetime(2024, 12, 31))}T17:58:44.549Z",
        "receivedDate": f"{faker.date_between_dates(date_start=datetime(2019, 1, 1), date_end=datetime(2024, 12, 31))}T18:58:44.549Z",
        "senderId": random.choice(company_ids),
        "protocolDate": f"{faker.date_between_dates(date_start=datetime(2019, 1, 1), date_end=datetime(2024, 12, 31))}T17:58:44.549Z",
        "attachmentBundleLink": faker.file_path(depth=3),
    }
    response = requests.post(f"{API_BASE}/letters", json=data, verify=False)
    # print(response.text)
    return response.json()["id"]


def create_workitem(assignee_id, project_id, letter_id):
    data = {
        "creationDate": "2025-07-20T18:08:20.560Z",
        "archivalDate": "2025-07-20T18:08:20.560Z",
        "assignmentDate": "2025-07-20T18:08:20.560Z",
        "assignmentNotes": faker.text(max_nb_chars=100),
        "assignedById": random.choice(user_ids),
        "currentState": random.randint(1, 4),
        "assigneeId": assignee_id,
        "projectId": project_id,
        "letterId": letter_id,
    }
    response = requests.post(f"{API_BASE}/workitems", json=data, verify=False)
    return response.status_code == 201


def main():
    for _ in range(NUM_ENTRIES):
        company_ids.append(create_company())
        user_ids.append(create_user())
        project_ids.append(create_project())
        letter_ids.append(create_letter())

    for i in range(NUM_ENTRIES):
        res = create_workitem(
            assignee_id=random.choice(user_ids),
            project_id=random.choice(project_ids),
            letter_id=random.choice(letter_ids),
        )
        if not res:
            print(f"Failed to create workitem for entry {i + 1}")

    print("Seeding complete.")


if __name__ == "__main__":
    main()
