// hooks/useWorkItems.ts
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { CreateWorkItemDto } from "@/api/data-contracts";
import { Api } from "../app/api/apiClient";

const api = new Api();

export function useGetWorkItems() {
  return useQuery({
    queryKey: ["workItems"],
    queryFn: async () => {
      const response = await api.workItemsList();
      return response.data ?? []; // extract array safely
    },
  });
}

export function useGetWorkItemsWithFilters(filters: {
  assigneeId?: string;
  projectId?: string;
  companyId?: string;
  state?: number;
}) {
  return useQuery({
    queryKey: ["workItems", filters],
    queryFn: async () => {
      const response = await api.workItemsList(filters);
      return response.data ?? []; // extract array safely
    },
    // refetchOnWindowFocus: false, // optional, if you want to disable refetching on window focus
    // staleTime: 1000 * 60 * 5, // optional, if you want to set a stale time
  });
}

export function useCreateWorkItem() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (newItem: CreateWorkItemDto) => api.workItemsCreate(newItem),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["workItems"] });
    },
  });
}
export function useUpdateWorkItem() {
  const queryClient = useQueryClient();
  // ensure to fix the DTO type in the API as well if regenerating types
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: CreateWorkItemDto }) => {
      // Ensure creationDate is never null
      const safeData = {
        ...data,
        creationDate: data.creationDate === null ? undefined : data.creationDate,
      };
      return api.workItemsUpdate(id, safeData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["workItems"] });
    },
  });
}

export function useGetReferenceData() {
  const projectsQuery = useQuery({
    queryKey: ["projects"],
    queryFn: () => api.projectsList(),
  });
  const usersQuery = useQuery({
    queryKey: ["users"],
    queryFn: () => api.usersList(),
  });
  const lettersQuery = useQuery({
    queryKey: ["letters"],
    queryFn: () => api.lettersList(),
  });

  return {
    projects: projectsQuery.data ?? [],
    users: usersQuery.data ?? [],
    letters: lettersQuery.data ?? [],
    isLoading: projectsQuery.isLoading || usersQuery.isLoading || lettersQuery.isLoading,
    error: projectsQuery.error || usersQuery.error || lettersQuery.error,
  };
}

export function useDeleteWorkItem() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id: string) => api.workItemsDelete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["workItems"] });
    },
  });
}
