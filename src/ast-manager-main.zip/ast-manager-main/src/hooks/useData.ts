// hooks/useData.ts
import {
  useMutation,
  UseMutationResult,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";
import { Api } from "@/api/apiClient";
import { Company, StatsDto, User } from "../app/api/data-contracts";
import { HttpResponse } from "../app/api/http-client";

const api = new Api();

export function useGetUsers() {
  return useQuery({
    queryKey: ["users"],
    queryFn: async () => {
      const responses = await api.usersList();
      return responses.data;
    },
  });
}

export function useGetProjects() {
  return useQuery({
    queryKey: ["projects"],
    queryFn: async () => {
      const responses = await api.projectsList();
      return responses.data;
    },
  });
}

export function useGetLetters() {
  return useQuery({
    queryKey: ["letters"],
    queryFn: async () => {
      const responses = await api.lettersList();
      return responses.data;
    },
  });
}

export function useGetCompanies() {
  return useQuery({
    queryKey: ["companies"],
    queryFn: async () => {
      const responses = await api.companiesList();
      return responses.data;
    },
  });
}

export function useGetCompany(id: string) {
  return useQuery({
    queryKey: ["company", id],
    queryFn: async () => {
      const response = await api.companiesDetail(id);
      return response.data;
    },
  });
}

export function useGetUser(id: string) {
  return useQuery({
    queryKey: ["user", id],
    queryFn: async () => {
      const response = await api.usersDetail(id);
      return response.data;
    },
  });
}
export function useDeleteUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api.usersDelete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["users"] });
    },
  });
}

export function useGetProject(id: string, options?: { enabled?: boolean }) {
  return useQuery({
    queryKey: ["project", id],
    queryFn: async () => {
      const response = await api.projectsDetail(id);
      return response.data;
    },
    enabled: options?.enabled ?? true,
  });
}

export function useGetWorkItem(id: string) {
  return useQuery({
    queryKey: ["workItem", id],
    queryFn: async () => {
      const response = await api.workItemsDetail(id);
      return response.data;
    },
  });
}

export function useDeleteProject() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api.projectsDelete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["projects"] });
    },
  });
}

export function useGetLetter(id: string) {
  return useQuery({
    queryKey: ["letter", id],
    queryFn: async () => {
      const response = await api.lettersDetail(id);
      return response.data;
    },
  });
}

export function useDeleteLetter() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api.lettersDelete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["letters"] });
    },
  });
}

export function useDeleteCompany() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id: string) => api.companiesDelete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["companies"] });
    },
  });
}

export function useCreateCompany(): UseMutationResult<
  HttpResponse<Company, any>, // success return type
  Error, // error type
  Company, // variables passed to mutationFn
  unknown // context (optional)
> {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: Company) => api.companiesCreate(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["companies"] }),
  });
}

export function useUpdateCompany() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, body }: { id: string; body: Company }) =>
      api.companiesUpdate(id, body),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["companies"] }),
  });
}

export function useCreateUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: User) => api.usersCreate(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["users"] }),
  });
}

export function useUpdateUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, body }: { id: string; body: User }) =>
      api.usersUpdate(id, body),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["users"] }),
  });
}

export function useCreateProject() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: { name: string; description?: string | null }) =>
      api.projectsCreate(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["projects"] }),
  });
}

export function useUpdateProject() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      body,
    }: {
      id: string;
      body: { name: string; description?: string | null };
    }) => api.projectsUpdate(id, body),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["projects"] }),
  });
}

export function useCreateLetter() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: {
      protocolNumber: string;
      protocolDate?: string | null;
      senderId: string;
      senderProtocolNumber?: string | null;
      senderProtocolDate?: string | null;
      subject: string;
      body: string;
      receivedDate: string;
      attachmentBundleLink?: string | null;
    }) => api.lettersCreate(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["letters"] }),
  });
}

export function useUpdateLetter() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      body,
    }: {
      id: string;
      body: {
        protocolNumber: string;
        protocolDate?: string | null;
        senderId: string;
        senderProtocolNumber?: string | null;
        senderProtocolDate?: string | null;
        subject: string;
        body: string;
        receivedDate: string;
        attachmentBundleLink?: string | null;
      };
    }) => api.lettersUpdate(id, body),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["letters"] }),
  });
}

export function useCreateMeeting() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: {
      date: string;
      location: string;
      summary?: string | null;
      resourceUrl?: string | null;
      projectId: string;
      participantCompanyIds: string[];
    }) => api.meetingsCreate(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["meetings"] }),
  });
}

export function useUpdateMeeting() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      body,
    }: {
      id: string;
      body: {
        date: string;
        location: string;
        summary?: string | null;
        resourceUrl?: string | null;
        projectId: string;
        participantCompanyIds: string[];
      };
    }) => api.meetingsUpdate(id, body),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["meetings"] }),
  });
}

export function useGetMeetings() {
  return useQuery({
    queryKey: ["meetings"],
    queryFn: async () => {
      const responses = await api.meetingsList();
      return responses.data;
    },
  });
}

export function useGetMeeting(id: string) {
  return useQuery({
    queryKey: ["meeting", id],
    queryFn: async () => {
      const response = await api.meetingsDetail(id);
      return response.data;
    },
  });
}
export function useDeleteMeeting() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api.meetingsDelete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["meetings"] });
    },
  });
}

export function useGetStats() {
  return useQuery({
    queryKey: ["stats"],
    queryFn: async () => {
      const responses = await api.statsList();
      return responses.data as StatsDto;
    },
  });
}
