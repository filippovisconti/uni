import { useQuery } from "@tanstack/react-query";
import { Api } from "../app/api/apiClient";

const api = new Api();

export function useGetLettersWithFilters(filters: {
  protocolNumber?: string;
  subject?: string;
  dateFrom?: string;
  dateTo?: string;
}) {
  return useQuery({
    queryKey: ["letters", filters],
    queryFn: async () => {
      const response = await api.lettersList(filters);
      return response.data ?? [];
    },
  });
}
