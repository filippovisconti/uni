// hooks/usePartialData.ts
import { useQuery } from "@tanstack/react-query";
import { Api } from "@/api/apiClient";

const api = new Api();

export function useUsersByIds(ids: string[]) {
  return useQuery({
    queryKey: ["users", { ids }],
    queryFn: async () => {
      const responses = await Promise.all(ids.map((id) => api.usersDetail(id)));
      return responses.map((res) => res.data);
    },
    enabled: ids.length > 0,
  });
}

export function useProjectsByIds(ids: string[]) {
  return useQuery({
    queryKey: ["projects", { ids }],
    queryFn: async () => {
      const responses = await Promise.all(ids.map((id) => api.projectsDetail(id)));
      return responses.map((res) => res.data);
    },
    enabled: ids.length > 0,
  });
}

export function useLettersByIds(ids: string[]) {
  return useQuery({
    queryKey: ["letters", { ids }],
    queryFn: async () => {
      const responses = await Promise.all(ids.map((id) => api.lettersDetail(id)));
      return responses.map((res) => res.data);
    },
    enabled: ids.length > 0,
  });
}
