import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export enum WorkItemState {
  NotAssigned = 0,
  InProgress = 1,
  WaitingForApproval = 2,
  Closed = 3,
  Archived = 4,
}

export const workItemStateMeta: Record<
  WorkItemState,
  { label: string; abbr: string; color: string }
> = {
  [WorkItemState.NotAssigned]: {
    label: "Not Assigned",
    abbr: "NotAssigned",
    color: "bg-gray-100 text-gray-800",
  },
  [WorkItemState.InProgress]: {
    label: "In Progress",
    abbr: "InProgress",
    color: "bg-yellow-100 text-yellow-800",
  },
  [WorkItemState.WaitingForApproval]: {
    label: "Waiting For Approval",
    abbr: "WaitingForApproval",
    color: "bg-blue-100 text-blue-800",
  },
  [WorkItemState.Closed]: {
    label: "Closed",
    abbr: "Closed",
    color: "bg-green-100 text-green-800",
  },
  [WorkItemState.Archived]: {
    label: "Archived",
    abbr: "Archived",
    color: "bg-purple-100 text-purple-800",
  },
};
