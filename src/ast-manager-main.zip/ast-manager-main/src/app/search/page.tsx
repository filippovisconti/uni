"use client";
import SearchPageForm from "@/src/components/SearchPage";
import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";
import { useGetCompanies, useGetLetters, useGetProjects, useGetUsers } from "@/src/hooks/useData";

export default function SearchPage() {
  SetDefaultHeaderTitle({ title: "Search" });
  const { data: users, isLoading: isUsersLoading } = useGetUsers();
  const { data: projects, isLoading: isProjectsLoading } = useGetProjects();
  const { data: letters, isLoading: isLettersLoading } = useGetLetters();
  const { data: companies, isLoading: isCompaniesLoading } = useGetCompanies();

  if (isUsersLoading || isProjectsLoading || isLettersLoading || isCompaniesLoading) {
    return <div>Loading...</div>;
  }
  if (!users || !projects || !letters || !companies) {
    return <div>Data not found</div>;
  }

  return (
    <SearchPageForm lettersprop={letters} users={users} projects={projects} companies={companies} />
  );
}
