"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { SetDefaultHeaderTitle } from "../components/ui/header-title-context";

export default function Page() {
  SetDefaultHeaderTitle({ title: "Home" });

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 py-20 text-center space-y-10">
      <div className="max-w-2xl">
        <h1 className="text-5xl font-extrabold tracking-tight leading-tight text-balance">
          Welcome to AST Manager
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Track, manage, and visualize your work items with ease. Stay productive and organized with
          real-time insights.
        </p>
      </div>

      <div className="flex flex-wrap gap-4 justify-center">
        <Link href="/work-items">
          <Button className="text-base px-6 py-3">View Work Items</Button>
        </Link>
        <Link href="/letters">
          <Button variant="outline" className="text-base px-6 py-3">
            View Letters
          </Button>
        </Link>
      </div>

      <div className="text-sm text-muted-foreground">Contact us at mario@rossi.com</div>
    </div>
  );
}
