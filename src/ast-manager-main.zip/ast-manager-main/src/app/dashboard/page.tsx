"use client";

import { StatsDto, WorkItem } from "@/src/app/api/data-contracts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
// or any spinner component
import { useGetWorkItems } from "@/src/hooks/useWorkItems";

import { useState } from "react";
import { cn, WorkItemState, workItemStateMeta } from "@/lib/utils";
import WorkItemsTable from "@/src/components/work-items/WorkItemsTable";
import { ChartWorkItemsCreated } from "@/src/components/ui/ChartWorkItemsCreated";
import { useGetStats } from "@/src/hooks/useData";

export default function WorkItemDashboard() {
  const [activeState, setActiveState] = useState<number | null>(null);

  const {
    data: stats,
    isLoading: isLoadingStats,
    error: errorStats,
  } = useGetStats();

  if (isLoadingStats) return <p className="p-6">Loading...</p>;
  if (errorStats)
    return <p className="p-6 text-red-600">Failed to load data.</p>;

  const stateOrder = [0, 1, 2, 3, 4];
  const totals = {
    0: stats?.workItemsPerState?.[workItemStateMeta[0].abbr] ?? 0,
    1: stats?.workItemsPerState?.[workItemStateMeta[1].abbr] ?? 0,
    2: stats?.workItemsPerState?.[workItemStateMeta[2].abbr] ?? 0,
    3: stats?.workItemsPerState?.[workItemStateMeta[3].abbr] ?? 0,
    4: stats?.workItemsPerState?.[workItemStateMeta[4].abbr] ?? 0,
  };

  return (
    <div className="p-6 space-y-8">
      <h1 className="text-2xl font-bold">Work Items Dashboard</h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <Card
          onClick={() => setActiveState(null)}
          className={cn("cursor-pointer", {
            "ring-2 ring-blue-500": activeState === null,
          })}
        >
          <CardHeader>
            <CardTitle>Total Work Items</CardTitle>
          </CardHeader>
          <CardContent className="text-3xl font-bold">
            {stats?.totalWorkItems}
          </CardContent>
        </Card>

        {stateOrder.map((state) => (
          <Card
            key={state}
            onClick={() =>
              setActiveState((prev) => (prev === state ? null : state))
            }
            className={cn("cursor-pointer", {
              "ring-2 ring-blue-500": activeState === state,
            })}
          >
            <CardHeader>
              <CardTitle>
                {workItemStateMeta[state as WorkItemState]?.label}
              </CardTitle>
            </CardHeader>
            <CardContent className="text-3xl font-semibold">
              {totals[state as keyof typeof totals] ?? 0}
            </CardContent>
          </Card>
        ))}
      </div>

      {activeState !== null ? (
        <WorkItemsTable filters={{ state: activeState }} />
      ) : (
        <ChartWorkItemsCreated />
      )}
    </div>
  );
}
