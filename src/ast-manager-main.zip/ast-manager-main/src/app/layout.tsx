"use client";
import "./globals.css";
import { ReactQueryProvider } from "../providers/ReactQueryProvider";
import { Toaster } from "sonner";
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/ui/app-sidebar";
import { SiteHeader } from "@/components/ui/site-header";
import {
  HeaderTitleProvider,
  SetDefaultHeaderTitle,
} from "@/components/ui/header-title-context";
import { ThemeProvider } from "../components/ui/theme-provider";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html suppressHydrationWarning>
      <head />
      <body>
        <ReactQueryProvider>
          <ThemeProvider
            attribute="class"
            defaultTheme="light"
            enableSystem
            disableTransitionOnChange
          >
            <SidebarProvider
              style={
                {
                  "--sidebar-width": "calc(var(--spacing) * 72)",
                  "--header-height": "calc(var(--spacing) * 12)",
                } as React.CSSProperties
              }
            >
              <HeaderTitleProvider>
                <AppSidebar variant="inset" />
                <SidebarInset>
                  <SetDefaultHeaderTitle title="Welcome" />
                  <SiteHeader />
                  {children}
                </SidebarInset>
              </HeaderTitleProvider>
            </SidebarProvider>
            <Toaster />
          </ThemeProvider>
        </ReactQueryProvider>
      </body>
    </html>
  );
}
