/* eslint-disable */
/* tslint:disable */
// @ts-nocheck
/*
 * ---------------------------------------------------------------
 * ## THIS FILE WAS GENERATED VIA SWAGGER-TYPESCRIPT-API        ##
 * ##                                                           ##
 * ## AUTHOR: acacode                                           ##
 * ## SOURCE: https://github.com/acacode/swagger-typescript-api ##
 * ---------------------------------------------------------------
 */

import {
  Address,
  Company,
  CreateWorkItemDto,
  Letter,
  LetterDto,
  Meeting,
  MeetingDto,
  Project2,
  User,
  WorkItem,
  WorkItemState,
} from "./data-contracts";
import { ContentType, HttpClient, RequestParams } from "./http-client";

export class Api<
  SecurityDataType = unknown,
> extends HttpClient<SecurityDataType> {
  /**
   * No description
   *
   * @tags Addresses
   * @name AddressesList
   * @request GET:/api/Addresses
   */
  addressesList = (params: RequestParams = {}) =>
    this.request<Address[], any>({
      path: `/api/Addresses`,
      method: "GET",
      format: "json",
      ...params,
    });
  /**
   * No description
   *
   * @tags Addresses
   * @name AddressesCreate
   * @request POST:/api/Addresses
   */
  addressesCreate = (data: Address, params: RequestParams = {}) =>
    this.request<Address, any>({
      path: `/api/Addresses`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      format: "json",
      ...params,
    });
  /**
   * No description
   *
   * @tags Addresses
   * @name AddressesDetail
   * @request GET:/api/Addresses/{id}
   */
  addressesDetail = (id: string, params: RequestParams = {}) =>
    this.request<Address, any>({
      path: `/api/Addresses/${id}`,
      method: "GET",
      format: "json",
      ...params,
    });
  /**
   * No description
   *
   * @tags Addresses
   * @name AddressesUpdate
   * @request PUT:/api/Addresses/{id}
   */
  addressesUpdate = (id: string, data: Address, params: RequestParams = {}) =>
    this.request<void, any>({
      path: `/api/Addresses/${id}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });
  /**
   * No description
   *
   * @tags Addresses
   * @name AddressesDelete
   * @request DELETE:/api/Addresses/{id}
   */
  addressesDelete = (id: string, params: RequestParams = {}) =>
    this.request<void, any>({
      path: `/api/Addresses/${id}`,
      method: "DELETE",
      ...params,
    });
  /**
   * No description
   *
   * @tags Companies
   * @name CompaniesList
   * @request GET:/api/Companies
   */
  companiesList = (params: RequestParams = {}) =>
    this.request<Company[], any>({
      path: `/api/Companies`,
      method: "GET",
      format: "json",
      ...params,
    });
  /**
   * No description
   *
   * @tags Companies
   * @name CompaniesCreate
   * @request POST:/api/Companies
   */
  companiesCreate = (data: Company, params: RequestParams = {}) =>
    this.request<Company, any>({
      path: `/api/Companies`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      format: "json",
      ...params,
    });
  /**
   * No description
   *
   * @tags Companies
   * @name CompaniesDetail
   * @request GET:/api/Companies/{id}
   */
  companiesDetail = (id: string, params: RequestParams = {}) =>
    this.request<Company, any>({
      path: `/api/Companies/${id}`,
      method: "GET",
      format: "json",
      ...params,
    });
  /**
   * No description
   *
   * @tags Companies
   * @name CompaniesUpdate
   * @request PUT:/api/Companies/{id}
   */
  companiesUpdate = (id: string, data: Company, params: RequestParams = {}) =>
    this.request<void, any>({
      path: `/api/Companies/${id}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });
  /**
   * No description
   *
   * @tags Companies
   * @name CompaniesDelete
   * @request DELETE:/api/Companies/{id}
   */
  companiesDelete = (id: string, params: RequestParams = {}) =>
    this.request<void, any>({
      path: `/api/Companies/${id}`,
      method: "DELETE",
      ...params,
    });
  /**
   * No description
   *
   * @tags Letters
   * @name LettersList
   * @request GET:/api/Letters
   */
  lettersList = (
    query?: {
      protocolNumber?: string;
      subject?: string;
      /** @format date-time */
      dateFrom?: string;
      /** @format date-time */
      dateTo?: string;
    },
    params: RequestParams = {}
  ) =>
    this.request<Letter[], any>({
      path: `/api/Letters`,
      method: "GET",
      query: query,
      format: "json",
      ...params,
    });
  /**
   * No description
   *
   * @tags Letters
   * @name LettersCreate
   * @request POST:/api/Letters
   */
  lettersCreate = (data: LetterDto, params: RequestParams = {}) =>
    this.request<Letter, any>({
      path: `/api/Letters`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      format: "json",
      ...params,
    });
  /**
   * No description
   *
   * @tags Letters
   * @name LettersDetail
   * @request GET:/api/Letters/{id}
   */
  lettersDetail = (id: string, params: RequestParams = {}) =>
    this.request<Letter, any>({
      path: `/api/Letters/${id}`,
      method: "GET",
      format: "json",
      ...params,
    });
  /**
   * No description
   *
   * @tags Letters
   * @name LettersUpdate
   * @request PUT:/api/Letters/{id}
   */
  lettersUpdate = (id: string, data: LetterDto, params: RequestParams = {}) =>
    this.request<void, any>({
      path: `/api/Letters/${id}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });
  /**
   * No description
   *
   * @tags Letters
   * @name LettersDelete
   * @request DELETE:/api/Letters/{id}
   */
  lettersDelete = (id: string, params: RequestParams = {}) =>
    this.request<void, any>({
      path: `/api/Letters/${id}`,
      method: "DELETE",
      ...params,
    });
  /**
   * No description
   *
   * @tags Meetings
   * @name MeetingsCreate
   * @request POST:/api/Meetings
   */
  meetingsCreate = (data: MeetingDto, params: RequestParams = {}) =>
    this.request<void, any>({
      path: `/api/Meetings`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });
  /**
   * No description
   *
   * @tags Meetings
   * @name MeetingsList
   * @request GET:/api/Meetings
   */
  meetingsList = (params: RequestParams = {}) =>
    this.request<Meeting[], any>({
      path: `/api/Meetings`,
      method: "GET",
      format: "json",
      ...params,
    });
  /**
   * No description
   *
   * @tags Meetings
   * @name MeetingsDetail
   * @request GET:/api/Meetings/{id}
   */
  meetingsDetail = (id: string, params: RequestParams = {}) =>
    this.request<Meeting, any>({
      path: `/api/Meetings/${id}`,
      method: "GET",
      format: "json",
      ...params,
    });
  /**
   * No description
   *
   * @tags Meetings
   * @name MeetingsUpdate
   * @request PUT:/api/Meetings/{id}
   */
  meetingsUpdate = (id: string, data: MeetingDto, params: RequestParams = {}) =>
    this.request<void, any>({
      path: `/api/Meetings/${id}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });
  /**
   * No description
   *
   * @tags Meetings
   * @name MeetingsDelete
   * @request DELETE:/api/Meetings/{id}
   */
  meetingsDelete = (id: string, params: RequestParams = {}) =>
    this.request<void, any>({
      path: `/api/Meetings/${id}`,
      method: "DELETE",
      ...params,
    });
  /**
   * No description
   *
   * @tags Projects
   * @name ProjectsList
   * @request GET:/api/Projects
   */
  projectsList = (params: RequestParams = {}) =>
    this.request<Project2[], any>({
      path: `/api/Projects`,
      method: "GET",
      format: "json",
      ...params,
    });
  /**
   * No description
   *
   * @tags Projects
   * @name ProjectsCreate
   * @request POST:/api/Projects
   */
  projectsCreate = (data: Project2, params: RequestParams = {}) =>
    this.request<Project2, any>({
      path: `/api/Projects`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      format: "json",
      ...params,
    });
  /**
   * No description
   *
   * @tags Projects
   * @name ProjectsDetail
   * @request GET:/api/Projects/{id}
   */
  projectsDetail = (id: string, params: RequestParams = {}) =>
    this.request<Project2, any>({
      path: `/api/Projects/${id}`,
      method: "GET",
      format: "json",
      ...params,
    });
  /**
   * No description
   *
   * @tags Projects
   * @name ProjectsUpdate
   * @request PUT:/api/Projects/{id}
   */
  projectsUpdate = (id: string, data: Project2, params: RequestParams = {}) =>
    this.request<void, any>({
      path: `/api/Projects/${id}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });
  /**
   * No description
   *
   * @tags Projects
   * @name ProjectsDelete
   * @request DELETE:/api/Projects/{id}
   */
  projectsDelete = (id: string, params: RequestParams = {}) =>
    this.request<void, any>({
      path: `/api/Projects/${id}`,
      method: "DELETE",
      ...params,
    });
  /**
   * No description
   *
   * @tags Stats
   * @name StatsList
   * @request GET:/api/Stats
   */
  statsList = (params: RequestParams = {}) =>
    this.request<WorkItemState, any>({
      path: `/api/Stats`,
      method: "GET",
      format: "json",
      ...params,
    });
  /**
   * No description
   *
   * @tags Users
   * @name UsersList
   * @request GET:/api/Users
   */
  usersList = (params: RequestParams = {}) =>
    this.request<User[], any>({
      path: `/api/Users`,
      method: "GET",
      format: "json",
      ...params,
    });
  /**
   * No description
   *
   * @tags Users
   * @name UsersCreate
   * @request POST:/api/Users
   */
  usersCreate = (data: User, params: RequestParams = {}) =>
    this.request<User, any>({
      path: `/api/Users`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      format: "json",
      ...params,
    });
  /**
   * No description
   *
   * @tags Users
   * @name UsersDetail
   * @request GET:/api/Users/{id}
   */
  usersDetail = (id: string, params: RequestParams = {}) =>
    this.request<User, any>({
      path: `/api/Users/${id}`,
      method: "GET",
      format: "json",
      ...params,
    });
  /**
   * No description
   *
   * @tags Users
   * @name UsersUpdate
   * @request PUT:/api/Users/{id}
   */
  usersUpdate = (id: string, data: User, params: RequestParams = {}) =>
    this.request<void, any>({
      path: `/api/Users/${id}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });
  /**
   * No description
   *
   * @tags Users
   * @name UsersDelete
   * @request DELETE:/api/Users/{id}
   */
  usersDelete = (id: string, params: RequestParams = {}) =>
    this.request<void, any>({
      path: `/api/Users/${id}`,
      method: "DELETE",
      ...params,
    });
  /**
   * No description
   *
   * @tags WorkItems
   * @name WorkItemsDetail
   * @request GET:/api/WorkItems/{id}
   */
  workItemsDetail = (id: string, params: RequestParams = {}) =>
    this.request<WorkItem, any>({
      path: `/api/WorkItems/${id}`,
      method: "GET",
      format: "json",
      ...params,
    });
  /**
   * No description
   *
   * @tags WorkItems
   * @name WorkItemsUpdate
   * @request PUT:/api/WorkItems/{id}
   */
  workItemsUpdate = (id: string, data: WorkItem, params: RequestParams = {}) =>
    this.request<void, any>({
      path: `/api/WorkItems/${id}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });
  /**
   * No description
   *
   * @tags WorkItems
   * @name WorkItemsDelete
   * @request DELETE:/api/WorkItems/{id}
   */
  workItemsDelete = (id: string, params: RequestParams = {}) =>
    this.request<void, any>({
      path: `/api/WorkItems/${id}`,
      method: "DELETE",
      ...params,
    });
  /**
   * No description
   *
   * @tags WorkItems
   * @name WorkItemsList
   * @request GET:/api/WorkItems
   */
  workItemsList = (
    query?: {
      /** @format uuid */
      assigneeId?: string;
      /** @format uuid */
      projectId?: string;
      /** @format uuid */
      companyId?: string;
      /** @format int32 */
      state?: number;
    },
    params: RequestParams = {}
  ) =>
    this.request<WorkItem[], any>({
      path: `/api/WorkItems`,
      method: "GET",
      query: query,
      format: "json",
      ...params,
    });
  /**
   * No description
   *
   * @tags WorkItems
   * @name WorkItemsCreate
   * @request POST:/api/WorkItems
   */
  workItemsCreate = (data: CreateWorkItemDto, params: RequestParams = {}) =>
    this.request<WorkItem, any>({
      path: `/api/WorkItems`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      format: "json",
      ...params,
    });

  /**
   * No description
   *
   * @tags Stats
   * @name StatsList
   * @request GET:/api/Stats
   */
  statsList = (params: RequestParams = {}) =>
    this.request<StatsDto, any>({
      path: `/api/Stats`,
      method: "GET",
      format: "json",
      ...params,
    });
}
