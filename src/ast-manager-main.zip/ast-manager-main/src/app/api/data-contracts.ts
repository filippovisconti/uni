/* eslint-disable */
/* tslint:disable */
// @ts-nocheck
/*
 * ---------------------------------------------------------------
 * ## THIS FILE WAS GENERATED VIA SWAGGER-TYPESCRIPT-API        ##
 * ##                                                           ##
 * ## AUTHOR: acacode                                           ##
 * ## SOURCE: https://github.com/acacode/swagger-typescript-api ##
 * ---------------------------------------------------------------
 */

export interface Address {
  /** @format uuid */
  id?: string;
  street: string;
  houseNumber: string;
  city: string;
  province: string;
  postalCode: string;
  country: string;
}

export interface Company {
  /** @format uuid */
  id?: string;
  name: string;
  address: Address;
  contactEmail?: string | null;
  contactPhone?: string | null;
}

export interface CreateWorkItemDto {
  /** @format date-time */
  creationDate?: string | null;
  currentState?: WorkItemState;
  /** @format date-time */
  archivalDate?: string | null;
  /** @format date-time */
  assignmentDate: string;
  /**
   * @minLength 0
   * @maxLength 1000
   */
  assignmentNotes: string;
  /** @format uuid */
  assigneeId: string;
  /** @format uuid */
  assignedById: string;
  /** @format uuid */
  letterId: string;
  /** @format uuid */
  projectId?: string | null;
}

export interface Letter {
  /** @format uuid */
  id?: string;
  protocolNumber: string;
  /** @format date-time */
  protocolDate: string | null;
  sender: Company;
  senderProtocolNumber?: string | null;
  /** @format date-time */
  senderProtocolDate?: string | null;
  subject: string;
  body: string;
  /** @format date-time */
  receivedDate: string;
  /** @format uri */
  attachmentBundleLink?: string | null;
}

export type Letter2 = {
  /** @format uuid */
  id?: string;
  protocolNumber: string;
  /** @format date-time */
  protocolDate: string | null;
  sender: Company;
  senderProtocolNumber?: string | null;
  /** @format date-time */
  senderProtocolDate?: string | null;
  subject: string;
  body: string;
  /** @format date-time */
  receivedDate: string;
  /** @format uri */
  attachmentBundleLink?: string | null;
};

export interface LetterDto {
  protocolNumber: string;
  /** @format date-time */
  protocolDate?: string | null;
  /** @format uuid */
  senderId: string;
  senderProtocolNumber?: string | null;
  /** @format date-time */
  senderProtocolDate?: string | null;
  subject: string;
  body: string;
  /** @format date-time */
  receivedDate: string;
  /** @format uri */
  attachmentBundleLink?: string | null;
}

export interface Meeting {
  /** @format uuid */
  id?: string;
  /** @format date-time */
  date: string;
  /**
   * @minLength 0
   * @maxLength 255
   */
  location: string;
  /**
   * @minLength 0
   * @maxLength 500
   */
  summary?: string | null;
  /** @format uri */
  resourceUrl?: string | null;
  /** @format uuid */
  projectId: string;
  project?: Project;
  participantCompanyIds: string[];
}

export interface MeetingDto {
  /** @format date-time */
  date?: string;
  /**
   * @minLength 0
   * @maxLength 255
   */
  location: string;
  /**
   * @minLength 0
   * @maxLength 500
   */
  summary?: string | null;
  /** @format uri */
  resourceUrl?: string | null;
  /** @format uuid */
  projectId: string;
  project?: Project;
  participantCompanyIds: string[];
}

export type Project = {
  /** @format uuid */
  id?: string;
  name: string;
  description?: string | null;
};

export interface Project2 {
  /** @format uuid */
  id?: string;
  name: string;
  description?: string | null;
}

export interface StatsDto {
  /** @format int32 */
  totalWorkItems?: number;
  workItemsPerState?: Record<string, number>;
  /** @format int32 */
  totalProjects?: number;
  /** @format int32 */
  totalCompanies?: number;
  /** @format int32 */
  totalLetters?: number;
  /** @format int32 */
  totalMeetings?: number;
}

export interface User {
  /** @format uuid */
  id?: string;
  firstName: string;
  lastName: string;
  nickname: string | null;
}

export type User2 = {
  /** @format uuid */
  id?: string;
  firstName: string;
  lastName: string;
  nickname: string | null;
};

export interface WorkItem {
  /** @format uuid */
  id?: string;
  /** @format date-time */
  creationDate?: string;
  currentState?: WorkItemState;
  /** @format date-time */
  archivalDate?: string | null;
  /** @format date-time */
  assignmentDate?: string;
  assignmentNotes: string;
  /** @format uuid */
  assigneeId: string;
  assignee?: User2;
  /** @format uuid */
  assignedById: string;
  assignedBy?: User2;
  /** @format uuid */
  letterId: string;
  letter?: Letter2;
  /** @format uuid */
  projectId?: string | null;
  project?: Project;
}

export type WorkItemState = number;
