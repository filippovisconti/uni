"use client";

import { ResourcePage } from "@/components/ui/ResourcePage";
import { projectColumns } from "@/components/projects/columns";
import { useDeleteProject, useGetProjects } from "@/src/hooks/useData";
import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";

export default function ProjectsPage() {
  SetDefaultHeaderTitle({ title: "Projects" });
  return (
    <ResourcePage
      title="Projects"
      newPath="/projects/new"
      getHook={useGetProjects}
      deleteHook={useDeleteProject}
      columns={projectColumns}
      basePath="/projects"
    />
  );
}
