"use client";

import { notFound, useParams, useRouter } from "next/navigation";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { useDeleteProject, useGetProject } from "@/src/hooks/useData";
import WorkItemsTable from "@/src/components/work-items/WorkItemsTable";
import { toast } from "sonner";
import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";

export default function ProjectDetailPage() {
  SetDefaultHeaderTitle({ title: "Project Details" });

  const router = useRouter();
  const params = useParams();
  const id = typeof params.id === "string" ? params.id : params.id?.[0];
  if (!id) return notFound();

  const { data: project, isLoading } = useGetProject(id);
  const { mutate: deleteProject, isPending } = useDeleteProject();

  if (isLoading) {
    return (
      <Card className="p-6 m-6 space-y-4">
        <Skeleton className="h-8 w-[240px]" />
        <Skeleton className="h-4 w-[320px]" />
        <Skeleton className="h-4 w-[280px]" />
      </Card>
    );
  }

  if (!project) return notFound();

  return (
    <div className="p-6 space-y-6">
      <Card>
        <CardHeader>
          <h1 className="text-2xl font-bold">{project.name}</h1>
          <p className="text-muted-foreground">Project Details</p>
        </CardHeader>
        <CardContent>
          <Detail label="Description" value={project.description || "—"} />
        </CardContent>
      </Card>

      <div className="flex gap-4">
        <Button variant="secondary" onClick={() => router.back()}>
          ← Back
        </Button>
        <Button onClick={() => router.push(`/projects/${id}/edit`)}>✏️ Edit</Button>
        <Button
          variant="destructive"
          onClick={() =>
            deleteProject(project.id!, {
              onSuccess: () => {
                toast.success("Project deleted");
                router.push("/projects");
              },
              onError: () => toast.error("Failed to delete project"),
            })
          }
          disabled={isPending}
        >
          {isPending ? "..." : "Delete"}
        </Button>
      </div>

      <Card>
        <CardHeader>
          <h2 className="text-xl font-semibold">Work Items</h2>
        </CardHeader>
        <CardContent>
          <WorkItemsTable filters={{ projectId: project.id }} />
        </CardContent>
      </Card>
    </div>
  );
}

function Detail({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="mb-2">
      <p className="text-sm font-medium text-muted-foreground">{label}</p>
      <p className="text-base">{value}</p>
    </div>
  );
}
