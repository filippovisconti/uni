"use client";

import { ProjectForm } from "@/src/components/projects/ProjectForm";
import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";
import { useGetProject } from "@/src/hooks/useData";
import { useParams } from "next/navigation";

export default function EditProjectPage() {
  SetDefaultHeaderTitle({ title: "Edit Project" });
  const params = useParams();
  const id = Array.isArray(params.id) ? params.id[0] : params.id;

  if (!id) {
    return <p>Project ID is missing.</p>;
  }
  const { data: project, isLoading, error } = useGetProject(id);

  if (isLoading) return <p>Loading...</p>;
  if (error || !project) return <p>Project not found.</p>;

  return <ProjectForm initialData={project} />;
}
