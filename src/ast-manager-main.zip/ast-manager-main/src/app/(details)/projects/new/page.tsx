"use client";

import { ProjectForm } from "@/src/components/projects/ProjectForm";
import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";

export default function NewProjectPage() {
  SetDefaultHeaderTitle({ title: "New Project" });
  return <ProjectForm />;
}
