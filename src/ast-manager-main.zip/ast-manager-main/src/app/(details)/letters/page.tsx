"use client";

import { ResourcePage } from "@/components/ui/ResourcePage";
import { letterColumns } from "@/components/letters/columns";
import { useDeleteLetter, useGetLetters } from "@/src/hooks/useData";
import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";

export default function LettersPage() {
  SetDefaultHeaderTitle({ title: "Letters" });
  return (
    <ResourcePage
      title="Letters"
      newPath="/letters/new"
      getHook={useGetLetters}
      deleteHook={useDeleteLetter}
      columns={letterColumns}
      basePath="/letters"
    />
  );
}
