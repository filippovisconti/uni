"use client";
import { LetterForm } from "@/src/components/letters/LetterForm";
import { useGetCompanies } from "@/src/hooks/useData";

export default function NewLetterPage() {
  // get companies from the API
  const { data: companies, isLoading, error } = useGetCompanies();
  if (isLoading) return <p className="p-4">Loading companies...</p>;
  if (error) return <p className="p-4 text-red-500">Error loading companies</p>;

  return <LetterForm companies={companies} />;
}
