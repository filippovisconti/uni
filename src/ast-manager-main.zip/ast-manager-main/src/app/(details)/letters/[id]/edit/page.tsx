"use client";

import { LetterForm } from "@/src/components/letters/LetterForm";
import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";
import { useGetCompanies, useGetLetter } from "@/src/hooks/useData";
import { notFound, useParams } from "next/navigation";

export default function EditLetterPage() {
  SetDefaultHeaderTitle({ title: "Edit Letter" });
  const params = useParams();
  const id = Array.isArray(params.id) ? params.id[0] : params.id;

  if (!id) {
    return <p>Invalid letter ID</p>;
  }

  const { data: companies, isLoading: isCompaniesLoading } = useGetCompanies();
  const { data: letter, isLoading: isLetterLoading } = useGetLetter(id);

  if (isLetterLoading || isCompaniesLoading) return <p>Loading...</p>;
  if (!letter) return notFound();

  return <LetterForm initialData={letter} companies={companies} />;
}
