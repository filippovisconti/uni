"use client";

import { useParams, useRouter } from "next/navigation";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { useDeleteLetter, useGetLetter } from "@/src/hooks/useData";
import { toast } from "sonner";
import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";
import { format } from "date-fns";
import Link from "next/link";

export default function LetterDetailPage() {
  SetDefaultHeaderTitle({ title: "Letter Details" });

  const router = useRouter();
  const params = useParams();
  const id = typeof params.id === "string" ? params.id : params.id?.[0];

  if (!id) return <p>Invalid letter ID</p>;

  const { data: letter, isLoading } = useGetLetter(id);
  const { mutate: deleteLetter, isPending } = useDeleteLetter();

  if (isLoading) return <Skeleton className="h-6 w-[200px]" />;
  if (!letter) return <p>Letter not found</p>;

  return (
    <div className="p-6 space-y-6">
      <Card>
        <CardHeader>
          <h1 className="text-2xl font-bold">Subject: {letter.subject} </h1>
          <p className="text-muted-foreground text-sm">Letter Details</p>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Detail label="Protocol Number" value={letter.protocolNumber} />
          <Detail
            label="Protocol Date"
            value={letter.protocolDate ? format(new Date(letter.protocolDate), "PPP") : "—"}
          />
          <Link href={`/companies/${letter.sender?.id ?? "#"}`}>
            <Detail label="Sender" value={letter.sender?.name ?? "—"} />
          </Link>
          <Detail label="Sender Protocol Number" value={letter.senderProtocolNumber ?? "—"} />
          <Detail
            label="Sender Protocol Date"
            value={
              letter.senderProtocolDate ? format(new Date(letter.senderProtocolDate), "PPP") : "—"
            }
          />
          <Detail
            label="Received Date"
            value={letter.receivedDate ? format(new Date(letter.receivedDate), "PPP") : "—"}
          />
          <div className="md:col-span-2">
            <Detail label="Body" value={letter.body ?? "—"} />
          </div>
          <div className="md:col-span-2">
            <Detail
              label="Attachment Bundle"
              value={
                letter.attachmentBundleLink ? (
                  <Link
                    href={letter.attachmentBundleLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 underline"
                  >
                    View Attachment
                  </Link>
                ) : (
                  "—"
                )
              }
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-4">
        <Button variant="secondary" onClick={() => router.back()}>
          ← Back
        </Button>
        <Link href={`/letters/${id}/edit`}>
          <Button>✏️ Edit</Button>
        </Link>
        <Button
          variant="destructive"
          onClick={() =>
            deleteLetter(letter.id!, {
              onSuccess: () => {
                toast.success("Letter deleted");
                router.push("/letters");
              },
              onError: () => toast.error("Failed to delete letter"),
            })
          }
          disabled={isPending}
        >
          {isPending ? "..." : "Delete"}
        </Button>
      </div>
    </div>
  );
}

function Detail({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <p className="text-sm font-medium text-muted-foreground">{label}</p>
      <p className="text-base break-words">{value}</p>
    </div>
  );
}
