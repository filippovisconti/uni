"use client";

import WorkItemsTable from "@/src/components/work-items/WorkItemsTable";
import Link from "next/link";
import { Button } from "@/src/components/ui/button";

import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";

export default function WorkItemsPage() {
  SetDefaultHeaderTitle({ title: "Work Items" });

  return (
    <div className="p-6">
      <div className="mb-4 flex justify-between items-center">
        <h1 className="text-xl font-bold">Work Items</h1>
        <Link href="/work-items/new">
          <Button>Add WorkItem</Button>
        </Link>
      </div>
      <WorkItemsTable />
    </div>
  );
}
