"use client";

import { useParams, useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { format } from "date-fns";

import {
  useGetLetter,
  useGetProject,
  useGetUser,
  useGetWorkItem,
} from "@/src/hooks/useData";
import { useDeleteWorkItem } from "@/src/hooks/useWorkItems";
import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";
import { WorkItemState, workItemStateMeta } from "@/src/lib/utils";
import Link from "next/link";

export default function WorkItemDetailPage() {
  SetDefaultHeaderTitle({ title: "Work Item Details" });

  const router = useRouter();
  const params = useParams();
  const id = typeof params.id === "string" ? params.id : params.id?.[0];

  if (!id) return <p>Invalid work item ID</p>;

  const { data: item, isLoading } = useGetWorkItem(id);
  const { data: letter } = useGetLetter(item?.letterId ?? "");
  const { data: project } = useGetProject(item?.projectId ?? "");
  const { data: assignee } = useGetUser(item?.assigneeId ?? "");
  const { data: assignedBy } = useGetUser(item?.assignedById ?? "");

  const { mutate: deleteWorkItem, isPending } = useDeleteWorkItem();

  const formatDate = (date?: string | null) =>
    date ? format(new Date(date), "PPP") : "—";

  if (isLoading) return <Skeleton className="h-6 w-[200px]" />;
  if (!item) return <p>Work item not found</p>;

  const stateMeta =
    workItemStateMeta[(item.currentState as WorkItemState) ?? 0];

  return (
    <div className="p-6 space-y-6">
      <Card>
        <CardHeader className="flex flex-col gap-2">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold">Work Item Details</h1>
            <Badge className={`${stateMeta.color} px-3 mx-5 py-1 text-sm`}>
              {stateMeta.label}
            </Badge>
          </div>
          <p className="text-muted-foreground text-sm">
            Created: {formatDate(item.creationDate)}
          </p>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Detail
            label="Assignee"
            value={
              assignee ? `${assignee.firstName} ${assignee.lastName}` : "—"
            }
            href={`/users/${assignee?.id}`}
          />
          <Detail
            label="Assigned By"
            value={
              assignedBy
                ? `${assignedBy.firstName} ${assignedBy.lastName}`
                : "—"
            }
            href={`/users/${assignedBy?.id}`}
          />
          <Detail
            label="Assignment Date"
            value={formatDate(item.assignmentDate)}
          />
          <Detail label="Archival Date" value={formatDate(item.archivalDate)} />
          <Detail
            label="Project"
            value={project?.name ?? "—"}
            href={`/projects/${project?.id}`}
          />
          <Detail
            label="Letter"
            value={
              letter ? `${letter.subject} (#${letter.protocolNumber})` : "—"
            }
            href={`/letters/${letter?.id}`}
          />
          <div className="md:col-span-2">
            <Detail label="Notes" value={item.assignmentNotes || "—"} />
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-4">
        <Button variant="secondary" onClick={() => router.back()}>
          ← Back
        </Button>
        <Button onClick={() => router.push(`/work-items/${id}/edit`)}>
          ✏️ Edit
        </Button>
        <Button
          variant="destructive"
          onClick={() => {
            deleteWorkItem(item.id!, {
              onSuccess: () => {
                toast.success("Work item deleted");
                router.push("/work-items");
              },
              onError: () => toast.error("Failed to delete work item"),
            });
          }}
          disabled={isPending}
        >
          {isPending ? "..." : "Delete"}
        </Button>
      </div>
    </div>
  );
}

function Detail({
  label,
  value,
  href,
}: {
  label: string;
  value: string;
  href?: string;
}) {
  return (
    <div>
      <p className="text-sm font-medium text-muted-foreground">{label}</p>
      <Link className="text-base" href={href ?? "#"}>
        {value}
      </Link>
    </div>
  );
}
