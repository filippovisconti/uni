"use client";

import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";
import { WorkItemForm } from "@/src/components/work-items/WorkItemForm";
import { useGetLetters, useGetProjects, useGetUsers, useGetWorkItem } from "@/src/hooks/useData";
import { useParams } from "next/navigation";

export default function EditWorkItemPage() {
  SetDefaultHeaderTitle({ title: "Edit Work Item" });
  const params = useParams();
  const id = typeof params.id === "string" ? params.id : params.id?.[0];
  if (!id) {
    return <p>Work Item ID is missing.</p>;
  }
  const { data: workItem, isLoading: isWorkItemLoading } = useGetWorkItem(id);
  if (isWorkItemLoading) return <p>Loading...</p>;
  if (!workItem) {
    return <p>Work Item not found.</p>;
  }
  const { data: users, isLoading: isUsersLoading } = useGetUsers();
  const { data: projects, isLoading: isProjectsLoading } = useGetProjects();
  const { data: letters, isLoading: isLettersLoading } = useGetLetters();

  if (isUsersLoading || isProjectsLoading || isLettersLoading) {
    return <div>Loading...</div>;
  }
  if (!users || !projects || !letters) {
    return <div>Data not found</div>;
  }

  return (
    <WorkItemForm initialData={workItem} users={users} projects={projects} letters={letters} />
  );
}
