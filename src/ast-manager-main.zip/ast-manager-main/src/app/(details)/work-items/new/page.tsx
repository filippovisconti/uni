"use client";

import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";
import { WorkItemForm } from "@/src/components/work-items/WorkItemForm";
import { useGetLetters, useGetProjects, useGetUsers } from "@/src/hooks/useData";
import { useSearchParams } from "next/navigation";

export default function NewWorkItemPage() {
  SetDefaultHeaderTitle({ title: "New Work Item" });
  const { data: users, isLoading: isUsersLoading } = useGetUsers();
  const { data: projects, isLoading: isProjectsLoading } = useGetProjects();
  const { data: letters, isLoading: isLettersLoading } = useGetLetters();
  const searchParams = useSearchParams();

  if (isUsersLoading || isProjectsLoading || isLettersLoading) {
    return <div>Loading...</div>;
  }
  if (!users || !projects || !letters) {
    return <div>Data not found</div>;
  }

  const preselectedLetterId = searchParams.get("letterId") ?? "";

  // add initialData only if letterid not null or empty
  return (
    <WorkItemForm
      users={users}
      projects={projects}
      letters={letters}
      {...(preselectedLetterId
        ? {
            initialData: {
              letterId: preselectedLetterId,
              assignmentNotes: "",
              assignedById: "",
              assigneeId: "",
            },
          }
        : {})}
    />
  );
}
