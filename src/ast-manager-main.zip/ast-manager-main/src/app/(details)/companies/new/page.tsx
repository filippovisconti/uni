"use client";

import { CompanyForm } from "@/components/companies/CompanyForm";
import { useHeaderTitle } from "@/src/components/ui/header-title-context";
import { useEffect } from "react";

export default function NewCompanyPage() {
  const { setTitle } = useHeaderTitle();

  useEffect(() => {
    setTitle("Add a New Company");
  }, [setTitle]);

  return <CompanyForm />;
}
