"use client";
import { CompanyForm } from "@/src/components/companies/CompanyForm";
import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";
import { useGetCompany } from "@/src/hooks/useData";
import { useParams } from "next/navigation";

export default function EditCompanyPage() {
  SetDefaultHeaderTitle({ title: "Edit Company" });
  const params = useParams();
  const id = Array.isArray(params.id) ? params.id[0] : params.id;

  if (!id) {
    return <p>Invalid company ID</p>;
  }

  const { data: company, isLoading } = useGetCompany(id);

  if (isLoading) return <p>Loading...</p>;
  if (!company) return <p>Company not found</p>;

  return <CompanyForm initialData={company} />;
}
