"use client";

import { useDeleteCompany, useGetCompany } from "@/src/hooks/useData";
import { toast } from "sonner";
import { notFound, useParams, useRouter } from "next/navigation";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import WorkItemsTable from "@/src/components/work-items/WorkItemsTable";
import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";

export default function CompanyDetailPage() {
  SetDefaultHeaderTitle({ title: "Company Details" });

  const router = useRouter();
  const params = useParams();
  const id = typeof params.id === "string" ? params.id : params.id?.[0];
  if (!id) return notFound();

  const { data: company, isLoading } = useGetCompany(id);
  const { mutate: deleteCompany, isPending } = useDeleteCompany();

  if (isLoading) {
    return (
      <Card className="p-6 m-6 space-y-4">
        <Skeleton className="h-8 w-[240px]" />
        <Skeleton className="h-4 w-[320px]" />
        <Skeleton className="h-4 w-[280px]" />
      </Card>
    );
  }

  if (!company) return notFound();

  return (
    <div className="p-6 space-y-6">
      <Card>
        <CardHeader>
          <h1 className="text-2xl font-bold">{company.name}</h1>
          <p className="text-muted-foreground">
            {company.contactEmail || "—"} · {company.contactPhone || "—"}
          </p>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Detail
            label="Street"
            value={`${company.address.street} ${company.address.houseNumber}`}
          />
          <Detail label="City" value={company.address.city} />
          <Detail label="Province" value={company.address.province} />
          <Detail label="Postal Code" value={company.address.postalCode} />
          <Detail label="Country" value={company.address.country} />
        </CardContent>
      </Card>

      <div className="flex gap-4">
        <Button variant="secondary" onClick={() => router.back()}>
          ← Back
        </Button>
        <Button onClick={() => router.push(`/companies/${id}/edit`)}>✏️ Edit</Button>
        <Button
          variant="destructive"
          onClick={() =>
            deleteCompany(company.id!, {
              onSuccess: () => {
                toast.success("Company deleted");
                router.push("/companies");
              },
              onError: () => toast.error("Failed to delete company"),
            })
          }
          disabled={isPending}
        >
          {isPending ? "..." : "Delete"}
        </Button>
      </div>

      <Card>
        <CardHeader>
          <h2 className="text-xl font-semibold">Work Items</h2>
        </CardHeader>
        <CardContent>
          <WorkItemsTable filters={{ companyId: company.id }} />
        </CardContent>
      </Card>
    </div>
  );
}

function Detail({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <p className="text-sm font-medium text-muted-foreground">{label}</p>
      <p className="text-base">{value}</p>
    </div>
  );
}
