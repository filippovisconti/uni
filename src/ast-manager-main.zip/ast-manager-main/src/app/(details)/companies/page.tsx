"use client";
import { columns } from "@/components/companies/columns";
import { ResourcePage } from "@/components/ui/ResourcePage";
import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";
import { useDeleteCompany, useGetCompanies } from "@/src/hooks/useData";

export default function CompaniesPage() {
  SetDefaultHeaderTitle({ title: "Companies" });
  return (
    <ResourcePage
      title="Companies"
      newPath="/companies/new"
      getHook={useGetCompanies}
      deleteHook={useDeleteCompany}
      columns={columns}
      basePath="/companies"
    />
  );
}
