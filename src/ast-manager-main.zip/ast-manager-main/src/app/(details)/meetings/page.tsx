"use client";

import { ResourcePage } from "@/components/ui/ResourcePage";
import { meetingColumns } from "@/src/components/meetings/columns";
import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";
import { useDeleteMeeting, useGetMeetings } from "@/src/hooks/useData";

export default function MeetingsPage() {
  SetDefaultHeaderTitle({ title: "Meetings" });
  return (
    <ResourcePage
      title="Meetings"
      newPath="/meetings/new"
      getHook={useGetMeetings}
      deleteHook={useDeleteMeeting}
      columns={meetingColumns}
      basePath="/meetings"
    />
  );
}
