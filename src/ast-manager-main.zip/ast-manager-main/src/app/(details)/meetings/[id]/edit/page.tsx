"use client";

import { CreateMeetingForm } from "@/src/components/meetings/CreateMeetingForm";
import { useHeaderTitle } from "@/src/components/ui/header-title-context";
import { useGetCompanies, useGetMeeting, useGetProjects } from "@/src/hooks/useData";
import { notFound, useParams } from "next/navigation";
import { useEffect } from "react";

export default function EditMeetingPage() {
  const { setTitle } = useHeaderTitle();

  useEffect(() => {
    setTitle("Edit Meeting");
  }, [setTitle]);

  const params = useParams();
  const id = Array.isArray(params.id) ? params.id[0] : params.id;
  if (!id) {
    return <p>Invalid meeting ID</p>;
  }

  const { data: meeting, isLoading: isMeetingLoading } = useGetMeeting(id);
  const { data: companies, isLoading: isCompaniesLoading } = useGetCompanies();
  const { data: projects, isLoading: isProjectsLoading } = useGetProjects();
  if (isMeetingLoading || isCompaniesLoading || isProjectsLoading) {
    return <p>Loading...</p>;
  }
  if (!meeting) {
    return notFound();
  }
  return (
    <div className="flex flex-col gap-4">
      <CreateMeetingForm initialData={meeting} companies={companies} projects={projects} />
    </div>
  );
}
