"use client";

import { useParams, useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useGetMeeting, useGetProject, useGetCompanies } from "@/src/hooks/useData";
import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";
import { format } from "date-fns";
import Link from "next/link";

export default function MeetingDetailPage() {
  SetDefaultHeaderTitle({ title: "Meeting Details" });

  const router = useRouter();
  const params = useParams();
  const id = typeof params.id === "string" ? params.id : params.id?.[0];

  if (!id) return <p>Invalid meeting ID</p>;

  const { data: meeting, isLoading } = useGetMeeting(id);
  const { data: project } = useGetProject(meeting?.projectId ?? "");
  const { data: companies } = useGetCompanies();

  const formatDate = (date?: string | null) => (date ? format(new Date(date), "PPP") : "—");

  if (isLoading) return <Skeleton className="h-6 w-[200px]" />;
  if (!meeting) return <p>Meeting not found</p>;

  const participantCompanies = meeting.participantCompanyIds
    .map((id) => companies?.find((c) => c.id === id)?.name)
    .filter(Boolean);

  return (
    <div className="p-6 space-y-6">
      <Card>
        <CardHeader className="flex flex-col gap-1">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold">Meeting Details</h1>
          </div>
          <p className="text-muted-foreground text-sm">Date: {formatDate(meeting.date)}</p>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Detail label="Location" value={meeting.location} />
          <Detail label="Project" value={project?.name ?? "—"} />
          <Detail label="Summary" value={meeting.summary ? meeting.summary : "—"} />
          <Detail
            label="Resource URL"
            value={
              meeting.resourceUrl ? (
                <a
                  href={meeting.resourceUrl}
                  className="text-blue-600 underline"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {meeting.resourceUrl}
                </a>
              ) : (
                "—"
              )
            }
          />
          <div className="md:col-span-2">
            <Detail
              label="Participants"
              value={participantCompanies.length > 0 ? participantCompanies.join(", ") : "—"}
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-4">
        <Button variant="secondary" onClick={() => router.back()}>
          ← Back
        </Button>
        <Link href={`/meetings/${id}/edit`}>
          <Button>Edit</Button>
        </Link>
      </div>
    </div>
  );
}

function Detail({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <p className="text-sm font-medium text-muted-foreground">{label}</p>
      <p className="text-base break-words">{value}</p>
    </div>
  );
}
