"use client";

import { CreateMeetingForm } from "@/src/components/meetings/CreateMeetingForm";
import { useGetCompanies, useGetProjects } from "@/src/hooks/useData";

export default function NewMeetingPage() {
  const { data: companies, isLoading: companiesLoading } = useGetCompanies();
  const { data: projects, isLoading: projectsLoading } = useGetProjects();
  if (companiesLoading || projectsLoading) {
    return <p className="p-4">Loading...</p>;
  }
  if (!companies || !projects) {
    return <p className="p-4 text-red-500">Error loading data</p>;
  }
  return (
    <div className="flex flex-col gap-4">
      <CreateMeetingForm companies={companies} projects={projects} />
    </div>
  );
}
