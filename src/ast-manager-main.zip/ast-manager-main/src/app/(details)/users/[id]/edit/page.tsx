"use client";
import { UserForm } from "@/src/components/users/UserForm";
import { useParams } from "next/navigation";
import { useGetUser } from "@/src/hooks/useData";
import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";

export default function EditUserPage() {
  SetDefaultHeaderTitle({ title: "Edit User" });
  const params = useParams();
  const id = typeof params.id === "string" ? params.id : params.id?.[0];
  const { data: user, isLoading } = useGetUser(id ?? "");

  if (isLoading) return <div>Loading...</div>;
  if (!user) return <div>User not found</div>;

  return <UserForm initialData={user} />;
}
