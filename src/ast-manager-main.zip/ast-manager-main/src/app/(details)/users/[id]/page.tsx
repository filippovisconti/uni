"use client";

import { notFound, useParams, useRouter } from "next/navigation";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { useDeleteUser, useGetUser } from "@/src/hooks/useData";
import WorkItemsTable from "@/src/components/work-items/WorkItemsTable";
import { Card } from "@/src/components/ui/card";
import { toast } from "sonner";
import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";

export default function UserDetailPage() {
  SetDefaultHeaderTitle({ title: "User Details" });
  const router = useRouter();
  const params = useParams();
  const id = typeof params.id === "string" ? params.id : params.id?.[0];
  if (!id) return notFound();
  const { data: user, isLoading } = useGetUser(id);
  const { mutate: deleteUser, isPending } = useDeleteUser();
  if (isLoading) return <Skeleton className="h-6 w-[200px]" />;
  if (!user) return notFound();

  return (
    <Card className="p-6 space-y-4 m-6">
      <h1 className="text-xl font-bold">
        {user.firstName} {user.lastName} ({user.nickname})
      </h1>

      <WorkItemsTable filters={{ assigneeId: user.id }} />
      <div className="flex gap-4">
        <Button variant="secondary" onClick={() => router.back()}>
          ← Back
        </Button>
        <Button onClick={() => router.push(`/users/${id}/edit`)}>✏️ Edit</Button>
        <Button
          variant="destructive"
          onClick={() => {
            deleteUser(user.id!, {
              onSuccess: () => toast.success("User deleted"),
              onError: () => toast.error("Failed to delete company"),
            });
            router.push("/users");
          }}
          disabled={isPending}
        >
          {isPending ? "..." : "Delete"}
        </Button>
      </div>
    </Card>
  );
}
