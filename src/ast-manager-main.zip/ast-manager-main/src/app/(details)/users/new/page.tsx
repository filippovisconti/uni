import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";
import { UserForm } from "@/src/components/users/UserForm";

export default function NewUserPage() {
  SetDefaultHeaderTitle({ title: "New User" });
  return <UserForm />;
}
