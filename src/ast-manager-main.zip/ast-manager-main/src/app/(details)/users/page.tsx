"use client";

import { ResourcePage } from "@/components/ui/ResourcePage";
import { userColumns } from "@/components/users/columns";
import { SetDefaultHeaderTitle } from "@/src/components/ui/header-title-context";
import { useDeleteUser, useGetUsers } from "@/src/hooks/useData";

export default function UsersPage() {
  SetDefaultHeaderTitle({ title: "Employees" });
  return (
    <ResourcePage
      title="Users"
      newPath="/users/new"
      getHook={useGetUsers}
      deleteHook={useDeleteUser}
      columns={userColumns}
      basePath="/users"
    />
  );
}
