"use client";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center text-center space-y-6 px-4">
      <h1 className="text-4xl font-bold text-destructive">404</h1>
      <p className="text-lg text-muted-foreground">
        The page you’re looking for doesn’t exist or has been removed.
      </p>
      <Button onClick={() => window.history.back()}>Go Back</Button>
    </div>
  );
}
