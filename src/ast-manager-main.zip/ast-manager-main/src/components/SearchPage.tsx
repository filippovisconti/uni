"use client";

import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { WorkItemCard } from "@/components/cards/WorkItemCard";
import { LetterCard } from "@/components/cards/LetterCard";
import { useGetWorkItemsWithFilters } from "@/hooks/useWorkItems";
import { useGetLettersWithFilters } from "@/src/hooks/useLetters";
import { Company, Letter, Project, User, WorkItem } from "@/api/data-contracts";
import { EntityPicker } from "./EntityPicker";
import { workItemStateMeta } from "../lib/utils";
import { Button } from "./ui/button";

type SearchPageProps = {
  initialData?: WorkItem;
  users: User[];
  lettersprop: Letter[];
  projects: Project[];
  companies: Company[];
};

export default function SearchPageForm({
  users,
  lettersprop,
  projects,
  companies,
}: SearchPageProps) {
  const stateOptions = Object.entries(workItemStateMeta).map(([value, meta]) => ({
    label: meta.label,
    value,
  }));
  const [tab, setTab] = useState<"letter" | "workitem">("letter");

  const [letterFilters, setLetterFilters] = useState({
    protocolNumber: "",
    subject: "",
    dateFrom: "",
    dateTo: "",
  });

  const [workItemFilters, setWorkItemFilters] = useState({
    assigneeId: "",
    projectId: "",
    companyId: "",
    state: "",
  });

  const resetLetterFilters = () => {
    setLetterFilters({
      protocolNumber: "",
      subject: "",
      dateFrom: "",
      dateTo: "",
    });
  };

  const resetWorkItemFilters = () => {
    setWorkItemFilters({
      assigneeId: "",
      projectId: "",
      companyId: "",
      state: "",
    });
  };

  const { data: letters, isLoading: loadingLetters } = useGetLettersWithFilters({
    ...letterFilters,
    dateFrom: letterFilters.dateFrom || undefined,
    dateTo: letterFilters.dateTo || undefined,
  });

  const { data: workItems, isLoading: loadingWorkItems } = useGetWorkItemsWithFilters({
    ...workItemFilters,
    state: workItemFilters.state ? parseInt(workItemFilters.state) : undefined,
  });

  return (
    <div className="p-6 space-y-6 max-w-4xl mx-auto min-w-full">
      <Tabs value={tab} onValueChange={(v) => setTab(v as "letter" | "workitem")}>
        <TabsList>
          <TabsTrigger value="letter">Letters</TabsTrigger>
          <TabsTrigger value="workitem">Work Items</TabsTrigger>
        </TabsList>

        {/* LETTERS */}
        <TabsContent value="letter">
          <div className="space-y-3 mb-4">
            <label className="block text-sm font-medium mb-1">Protocol Number</label>
            <Input
              placeholder="Protocol Number"
              value={letterFilters.protocolNumber}
              onChange={(e) =>
                setLetterFilters((f) => ({
                  ...f,
                  protocolNumber: e.target.value,
                }))
              }
            />
            <label className="block text-sm font-medium mb-1">Subject</label>
            <Input
              placeholder="Subject"
              value={letterFilters.subject}
              onChange={(e) => setLetterFilters((f) => ({ ...f, subject: e.target.value }))}
            />
            <label className="block text-sm font-medium mb-1">Date From</label>
            <Input
              type="date"
              placeholder="Date From"
              value={letterFilters.dateFrom}
              onChange={(e) => setLetterFilters((f) => ({ ...f, dateFrom: e.target.value }))}
            />
            <label className="block text-sm font-medium mb-1">Date To</label>
            <Input
              type="date"
              placeholder="Date To"
              value={letterFilters.dateTo}
              onChange={(e) => setLetterFilters((f) => ({ ...f, dateTo: e.target.value }))}
            />
          </div>
          <Button variant="outline" className="mb-3" onClick={resetLetterFilters}>
            Clear Filters
          </Button>

          {loadingLetters ? (
            <Skeleton className="h-20 w-full" />
          ) : (
            <div className="grid gap-4">
              {letters?.map((l) => (
                <LetterCard key={l.id} letter={l} />
              ))}
            </div>
          )}
        </TabsContent>

        {/* WORK ITEMS */}
        <TabsContent value="workitem">
          <div className="space-y-3 mb-4">
            <label className="block text-sm font-medium mb-1">Assignee</label>
            <EntityPicker
              label="Assignee"
              options={users
                .filter((u): u is User & { id: string } => !!u.id)
                .map((u) => ({
                  label: `${u.firstName} ${u.lastName}`,
                  value: u.id,
                }))}
              value={workItemFilters.assigneeId}
              onChange={(e) =>
                setWorkItemFilters((f) => ({
                  ...f,
                  assigneeId: e,
                }))
              }
            />
            <label className="block text-sm font-medium mb-1">Project</label>
            <EntityPicker
              label="Project"
              options={projects
                .filter((p): p is Project & { id: string } => !!p.id)
                .map((p) => ({
                  label: p.name,
                  value: p.id,
                }))}
              value={workItemFilters.projectId}
              onChange={(e) => setWorkItemFilters((f) => ({ ...f, projectId: e }))}
            />
            <label className="block text-sm font-medium mb-1"> Company </label>
            <EntityPicker
              label="Company"
              options={companies
                .filter((c): c is Company & { id: string } => !!c.id)
                .map((c) => ({
                  label: c.name,
                  value: c.id,
                }))}
              value={workItemFilters.companyId}
              onChange={(e) => setWorkItemFilters((f) => ({ ...f, companyId: e }))}
            />
            <EntityPicker
              label="State"
              options={stateOptions}
              value={workItemFilters.state}
              onChange={(e) => setWorkItemFilters((f) => ({ ...f, state: e }))}
            />
          </div>
          <Button variant="outline" className="mb-3" onClick={resetWorkItemFilters}>
            Clear Filters
          </Button>

          {loadingWorkItems ? (
            <Skeleton className="h-20 w-full" />
          ) : (
            <div className="grid gap-4">
              {workItems?.map((item) => (
                <WorkItemCard key={item.id} workitem={item} />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
