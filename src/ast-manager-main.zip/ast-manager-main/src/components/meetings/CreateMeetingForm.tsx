"use client";

import { useForm } from "@tanstack/react-form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Company, Meeting, MeetingDto, Project } from "@/api/data-contracts";
import { useState } from "react";
import { EntityPicker } from "../EntityPicker";
import { useCreateMeeting, useUpdateMeeting } from "@/src/hooks/useData";

type MeetingFormProps = {
  companies: Company[];
  projects: Project[];
  initialData?: Meeting;
};

export function CreateMeetingForm({ companies, projects, initialData }: MeetingFormProps) {
  const router = useRouter();

  const [selectedParticipants, setSelectedParticipants] = useState<string[]>([]);

  const createMeetingMutation = useCreateMeeting();
  const updateMeetingMutation = useUpdateMeeting();

  const meetingId = initialData?.id;
  const isEditMode = Boolean(meetingId);

  const normalizedData: MeetingDto = {
    date: initialData?.date ?? "",
    location: initialData?.location ?? "",
    summary: initialData?.summary ?? "",
    resourceUrl: initialData?.resourceUrl ?? "",
    projectId: initialData?.projectId ?? "",
    participantCompanyIds: initialData?.participantCompanyIds || [],
  };

  const form = useForm({
    defaultValues: normalizedData,
    onSubmit: async ({ value }) => {
      try {
        const toUTCDateString = (dateStr: string | undefined) => {
          if (!dateStr) throw new Error("Date is required");
          if (dateStr.endsWith("Z")) return dateStr; // already in UTC
          if (!dateStr.includes("T")) {
            return new Date(dateStr + "T00:00:00").toISOString();
          }
          return dateStr;
        };
        const payload: MeetingDto = {
          ...value,
          date: toUTCDateString(value.date) || "",
          participantCompanyIds: selectedParticipants,
        };
        if (isEditMode) {
          await updateMeetingMutation.mutateAsync({
            id: meetingId!,
            body: payload,
          });
          toast.success("Meeting updated successfully");
        } else {
          await createMeetingMutation.mutateAsync(payload);
          toast.success("Meeting created successfully");
        }
        router.push("/meetings");
      } catch (err) {
        console.error(err);
        toast.error(
          "Failed to create meeting" + (err instanceof Response ? `: ${await err.text()}` : ""),
        );
      }
    },
  });

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        form.handleSubmit();
      }}
      className="space-y-4 p-6 max-w-xl mx-auto"
    >
      <h1 className="text-xl font-bold">New Meeting</h1>

      <form.Field name="date">
        {(field) => (
          <Input
            type="datetime-local"
            value={field.state.value ?? ""}
            onChange={(e) => field.handleChange(e.target.value)}
            required
          />
        )}
      </form.Field>

      <form.Field name="location">
        {(field) => (
          <Input
            placeholder="Location"
            value={field.state.value}
            onChange={(e) => field.handleChange(e.target.value)}
            required
          />
        )}
      </form.Field>

      <form.Field name="summary">
        {(field) => (
          <Textarea
            placeholder="Meeting Summary (max 500 characters)"
            maxLength={500}
            value={field.state.value ?? ""}
            onChange={(e) => field.handleChange(e.target.value)}
          />
        )}
      </form.Field>

      <form.Field name="resourceUrl">
        {(field) => (
          <Input
            placeholder="Resource URL"
            value={field.state.value ?? ""}
            onChange={(e) => field.handleChange(e.target.value)}
          />
        )}
      </form.Field>

      <form.Field name="projectId">
        {(field) => (
          <EntityPicker
            label="Project"
            options={projects.map((p) => ({
              label: p.name,
              value: p.id ?? "",
            }))}
            value={field.state.value}
            onChange={(val) => field.handleChange(val)}
          />
        )}
      </form.Field>

      {/* Participants multi-select */}
      <div>
        <label className="block text-sm font-medium mb-1">Participants (Companies)</label>
        <div className="grid grid-cols-2 gap-2">
          {companies.map((company) => {
            if (company.id === undefined) return null; // Skip if no ID
            const isSelected = selectedParticipants.includes(company.id);
            return (
              <button
                key={company.id}
                type="button"
                onClick={() =>
                  setSelectedParticipants((prev) =>
                    isSelected
                      ? prev.filter((id) => id !== company.id && typeof id === "string")
                      : [...prev, company.id as string],
                  )
                }
                className={`px-3 py-1 rounded border ${
                  isSelected ? "bg-blue-600 text-white" : "bg-white text-black hover:bg-gray-100"
                }`}
              >
                {company.name}
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex gap-4 mt-4">
        <Button variant="secondary" onClick={() => router.back()}>
          ← Back
        </Button>
        <Button type="submit">Create Meeting</Button>
      </div>
    </form>
  );
}
