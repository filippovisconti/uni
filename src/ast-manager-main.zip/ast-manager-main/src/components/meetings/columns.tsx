// src/components/letters/columns.tsx
import { Meeting } from "@/src/app/api/data-contracts";
import { ColumnDef } from "@tanstack/react-table";
import Link from "next/link";

export const meetingColumns = (): ColumnDef<Meeting>[] => {
  return [
    {
      accessorKey: "date",
      header: "Date",
      cell: ({ row }) => <span>{new Date(row.original.date).toLocaleDateString()}</span>,
    },
    {
      accessorKey: "location",
      header: "Location",
      cell: ({ row }) => <span>{row.original.location}</span>,
    },
    {
      accessorKey: "summary",
      header: "Summary",
      cell: ({ row }) => <span>{row.original.summary}</span>,
    },
    {
      accessorKey: "resourceUrl",
      header: "Resource URL",
      cell: ({ row }) => (
        <Link
          href={row.original.resourceUrl ?? "#"}
          target="_blank"
          rel="noopener noreferrer"
          className="underline text-blue-900"
        >
          {row.original.resourceUrl}
        </Link>
      ),
    },
    {
      accessorKey: "project.name",
      header: "Project",
      cell: ({ row }) => {
        const project = row.original.project;
        return project ? (
          <Link href={`/projects/${project.id}`} className="underline">
            {project.name}
          </Link>
        ) : (
          <span className="text-gray-500">{row.original.projectId}</span>
        );
      },
    },
    // {
    //   accessorKey: "participants",
    //   header: "Participants",
    //   cell: ({ row }) => (
    //     <span>{row.original.participantCompanyIds.join(", ") || "No participants"}</span>
    //   ),
    // },
  ];
};
