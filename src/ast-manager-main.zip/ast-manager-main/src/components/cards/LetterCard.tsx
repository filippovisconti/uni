"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Letter } from "@/src/app/api/data-contracts";
import Link from "next/link";

export function LetterCard({ letter }: { letter: Letter }) {
  return (
    <Card className="hover:shadow-md transition-shadow duration-200">
      <CardHeader>
        <CardTitle className="text-lg font-semibold truncate">{letter.subject}</CardTitle>
      </CardHeader>
      <CardContent className="text-sm text-muted-foreground space-y-1">
        {letter.sender && <div>From: {letter.sender.name}</div>}
        {letter.receivedDate && (
          <div>Received: {new Date(letter.receivedDate).toLocaleDateString()}</div>
        )}
        {letter.protocolDate && (
          <div>Protocol Date: {new Date(letter.protocolDate).toLocaleDateString()}</div>
        )}
        {letter.protocolNumber && <div>Protocol Number: {letter.protocolNumber}</div>}
        <Link href={`/letters/${letter.id}`} className="text-blue-500 hover:underline">
          View Details
        </Link>
      </CardContent>
    </Card>
  );
}
