"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Project } from "@/src/app/api/data-contracts";

export function ProjectCard({ project }: { project: Project }) {
  return (
    <Card className="hover:shadow-md transition-shadow duration-200">
      <CardHeader>
        <CardTitle className="text-lg font-semibold truncate">{project.name}</CardTitle>
      </CardHeader>
      <CardContent className="text-sm text-muted-foreground">
        {project.description || "No description available"}
      </CardContent>
    </Card>
  );
}
