import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { WorkItem } from "@/src/app/api/data-contracts";
import Link from "next/link";

export function WorkItemCard({ workitem }: { workitem: WorkItem }) {
  return (
    <Card className="hover:shadow-md transition-shadow duration-200">
      <CardHeader>
        <CardTitle className="text-lg font-semibold truncate">
          {workitem.project ? workitem.project.name : "Untitled Project"}
        </CardTitle>
      </CardHeader>
      <CardContent className="text-sm text-muted-foreground space-y-1">
        {workitem.currentState && <div>Status: {workitem.currentState}</div>}
        {workitem.creationDate && (
          <div>Arrived: {new Date(workitem.creationDate).toLocaleDateString()}</div>
        )}
        <Link href={`/work-items/${workitem.id}`} className="text-blue-500 hover:underline">
          View Details
        </Link>
      </CardContent>
    </Card>
  );
}
