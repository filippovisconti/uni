"use client";

import { useForm } from "@tanstack/react-form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import { useCreateProject, useUpdateProject } from "@/src/hooks/useData";
import { toast } from "sonner";

type ProjectFormProps = {
  initialData?: {
    id?: string;
    name: string;
    description?: string | null;
  };
};

export function ProjectForm({ initialData }: ProjectFormProps) {
  const router = useRouter();
  const isEditMode = Boolean(initialData?.id);
  const createProjectMutation = useCreateProject();
  const updateProjectMutation = useUpdateProject();

  const normalizedData = {
    name: initialData?.name ?? "",
    description: initialData?.description ?? "",
  };

  const form = useForm({
    defaultValues: normalizedData,
    onSubmit: async ({ value }) => {
      try {
        const payload = {
          name: value.name.trim(),
          description: value.description?.trim() || null,
          ...(isEditMode && initialData?.id ? { id: initialData.id } : {}),
        };
        if (isEditMode && initialData?.id) {
          await updateProjectMutation.mutateAsync({
            id: initialData.id,
            body: payload,
          });
        } else {
          await createProjectMutation.mutateAsync(payload);
        }

        router.push("/projects");
      } catch (err) {
        toast.error(
          "Failed to save project" +
            (err instanceof Response ? `: ${await err.text()}` : "")
        );
      }
    },
  });

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        form.handleSubmit();
      }}
      className="space-y-6 p-6 m-6  max-w-2xl mx-auto bg-background text-foreground shadow rounded-xl border border-border"
    >
      <h1 className="text-2xl font-bold">
        {isEditMode ? "Edit Project" : "New Project"}
      </h1>

      <form.Field name="name">
        {(field) => (
          <div>
            <label className="block text-sm font-medium mb-1 text-muted-foreground">
              Project Name
            </label>
            <Input
              required
              placeholder="Project name"
              value={field.state.value}
              onChange={(e) => field.handleChange(e.target.value)}
            />
          </div>
        )}
      </form.Field>

      <form.Field name="description">
        {(field) => (
          <div>
            <label className="block text-sm font-medium mb-1 text-muted-foreground">
              Description
            </label>
            <Textarea
              placeholder="Optional description"
              value={field.state.value}
              onChange={(e) => field.handleChange(e.target.value)}
              className="w-full min-h-[120px]"
            />
          </div>
        )}
      </form.Field>

      <div className="flex justify-end gap-4 pt-4">
        <Button variant="outline" onClick={() => router.back()} type="button">
          ← Cancel
        </Button>
        <Button
          type="submit"
          disabled={
            createProjectMutation.isPending || updateProjectMutation.isPending
          }
        >
          {isEditMode ? "Update Project" : "Create Project"}
        </Button>
      </div>
    </form>
  );
}
