// src/components/projects/columns.tsx
import { ColumnDef } from "@tanstack/react-table";
import { Project } from "@/api/data-contracts";

export const projectColumns = (): ColumnDef<Project>[] => [
  {
    accessorKey: "name",
    header: "Name",
    cell: ({ row }) => <span className="font-bold">{row.original.name}</span>,
  },
  {
    accessorKey: "description",
    header: "Description",
    cell: ({ row }) => {
      const project = row.original;
      return (
        <span className="text-sm text-gray-600">{project.description || "No description"}</span>
      );
    },
  },
];
