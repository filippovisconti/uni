"use client";

import { useForm } from "@tanstack/react-form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useRouter } from "next/navigation";
import { useCreateUser, useUpdateUser } from "@/src/hooks/useData";

export interface User {
  /** @format uuid */
  id?: string;
  firstName: string;
  lastName: string;
  nickname?: string | null;
  email?: string | null;
}

type UserFormProps = {
  initialData?: User;
};

export function UserForm({ initialData }: UserFormProps) {
  const router = useRouter();
  const createUserMutation = useCreateUser();
  const updateUserMutation = useUpdateUser();
  const isEditMode = Boolean(initialData?.id);

  const defaultValues = {
    firstName: initialData?.firstName ?? "",
    lastName: initialData?.lastName ?? "",
    nickname: initialData?.nickname ?? "",
  };

  const form = useForm({
    defaultValues,
    onSubmit: async ({ value }) => {
      try {
        const payload = {
          firstName: value.firstName.trim(),
          lastName: value.lastName.trim(),
          nickname: value.nickname?.trim() || null,
          ...(isEditMode && initialData?.id ? { id: initialData.id } : {}),
        };

        if (isEditMode && initialData?.id) {
          await updateUserMutation.mutateAsync({
            id: initialData.id,
            body: payload,
          });
        } else {
          await createUserMutation.mutateAsync(payload);
        }

        router.push("/users");
      } catch (err) {
        toast.error(
          "Failed to save user" +
            (err instanceof Response ? `: ${await err.text()}` : "")
        );
      }
    },
  });

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        form.handleSubmit();
      }}
      className="space-y-6 p-6 max-w-2xl mx-auto bg-background text-foreground shadow rounded-xl border border-border"
    >
      <h1 className="text-2xl font-bold">
        {isEditMode ? "Edit User" : "New User"}
      </h1>

      <form.Field name="firstName">
        {(field) => (
          <div>
            <label className="block text-sm font-medium mb-1 text-muted-foreground">
              First Name
            </label>
            <Input
              placeholder="First Name"
              value={field.state.value}
              onChange={(e) => field.handleChange(e.target.value)}
              required
            />
          </div>
        )}
      </form.Field>

      <form.Field name="lastName">
        {(field) => (
          <div>
            <label className="block text-sm font-medium mb-1 text-muted-foreground">
              Last Name
            </label>
            <Input
              placeholder="Last Name"
              value={field.state.value}
              onChange={(e) => field.handleChange(e.target.value)}
              required
            />
          </div>
        )}
      </form.Field>

      <form.Field name="nickname">
        {(field) => (
          <div>
            <label className="block text-sm font-medium mb-1 text-muted-foreground">
              Nickname
            </label>
            <Input
              placeholder="Nickname"
              value={field.state.value}
              onChange={(e) => field.handleChange(e.target.value)}
            />
          </div>
        )}
      </form.Field>

      <div className="flex justify-end gap-4 pt-4">
        <Button variant="outline" type="button" onClick={() => router.back()}>
          ← Cancel
        </Button>
        <Button
          type="submit"
          disabled={
            createUserMutation.isPending || updateUserMutation.isPending
          }
        >
          {isEditMode ? "Update User" : "Create User"}
        </Button>
      </div>
    </form>
  );
}
