// src/components/users/columns.tsx
import { ColumnDef } from "@tanstack/react-table";
import { User } from "@/api/data-contracts";

export const userColumns = (): ColumnDef<User>[] => [
  {
    accessorKey: "firstName",
    header: "First Name",
  },
  {
    accessorKey: "lastName",
    header: "Last Name",
  },
  {
    accessorKey: "nickname",
    header: "Nickname",
  },
];
