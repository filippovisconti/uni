"use client";

import { useForm } from "@tanstack/react-form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Company, Letter } from "@/api/data-contracts";
import { useRouter } from "next/navigation";
import { useCreateLetter, useUpdateLetter } from "@/src/hooks/useData";
import { useState } from "react";
import { Combobox, ComboboxOptions } from "@headlessui/react";
import { toast } from "sonner";
import { Textarea } from "@/components/ui/textarea";

type LetterFormProps = {
  initialData?: Letter;
  companies?: Company[];
};

export function LetterForm({ initialData, companies = [] }: LetterFormProps) {
  const createLetterMutation = useCreateLetter();
  const updateLetterMutation = useUpdateLetter();
  const router = useRouter();
  const letterId = initialData?.id;
  const isEditMode = Boolean(letterId);

  const normalizedData = {
    protocolNumber: initialData?.protocolNumber ?? "",
    protocolDate: initialData?.protocolDate ?? "",
    senderId: initialData?.sender.id ?? "",
    senderProtocolNumber: initialData?.senderProtocolNumber ?? "",
    senderProtocolDate: initialData?.senderProtocolDate ?? "",
    subject: initialData?.subject ?? "",
    body: initialData?.body ?? "",
    receivedDate: initialData?.receivedDate ?? "",
    attachmentBundleLink: initialData?.attachmentBundleLink ?? "",
  };

  const form = useForm({
    defaultValues: normalizedData,
    onSubmit: async ({ value }) => {
      try {
        const toUTCDateString = (dateStr: string | undefined) => {
          if (!dateStr) return null;
          if (dateStr.endsWith("Z")) return dateStr;
          const d = new Date(dateStr + "T00:00:00");
          return d.toISOString();
        };

        const payload = {
          ...value,
          protocolDate: toUTCDateString(value.protocolDate) ?? "",
          senderProtocolDate: toUTCDateString(value.senderProtocolDate) ?? "",
          receivedDate: toUTCDateString(value.receivedDate) ?? "",
        };

        if (isEditMode) {
          await updateLetterMutation.mutateAsync({
            id: letterId!,
            body: payload,
          });
        } else {
          await createLetterMutation.mutateAsync(payload);
        }
        router.push("/letters");
      } catch (err) {
        toast.error(
          "Failed to save letter" +
            (err instanceof Response ? `: ${await err.text()}` : "")
        );
      }
    },
  });

  const [query, setQuery] = useState("");
  const filteredCompanies =
    query === ""
      ? companies
      : companies.filter((u) =>
          u.name.toLowerCase().includes(query.toLowerCase())
        );

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        form.handleSubmit();
      }}
      className="space-y-6 p-6 m-6 w-2xl mx-auto bg-background text-foreground shadow rounded-xl border border-border"
    >
      <h1 className="text-2xl font-bold">
        {isEditMode ? "Edit Letter" : "New Letter"}
      </h1>

      {/* Protocol Info */}
      <fieldset className="space-y-4">
        <legend className="text-lg font-semibold mb-2 text-muted-foreground">
          Protocol Information
        </legend>

        <form.Field name="protocolNumber">
          {(field) => (
            <div>
              <label className="block text-sm font-medium mb-1 text-muted-foreground">
                Protocol Number
              </label>
              <Input
                placeholder="Protocol Number"
                value={field.state.value}
                onChange={(e) => field.handleChange(e.target.value)}
              />
            </div>
          )}
        </form.Field>

        <form.Field name="protocolDate">
          {(field) => (
            <div>
              <label className="block text-sm font-medium mb-1 text-muted-foreground">
                Protocol Date
              </label>
              <Input
                type="date"
                value={field.state.value?.slice(0, 10)}
                onChange={(e) => field.handleChange(e.target.value)}
              />
            </div>
          )}
        </form.Field>
      </fieldset>

      {/* Sender Info */}
      <fieldset className="space-y-4">
        <legend className="text-lg font-semibold mb-2 text-muted-foreground">
          Sender Information
        </legend>

        {companies.length > 0 && (
          <div>
            <label className="block text-sm font-medium mb-1 text-muted-foreground">
              Sender
            </label>
            <Combobox
              value={form.getFieldValue("senderId")}
              onChange={(val) => form.setFieldValue("senderId", val!)}
            >
              <Combobox.Input
                placeholder="Select Sender..."
                onChange={(e) => setQuery(e.target.value)}
                className="border-input placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive dark:bg-input/30 flex min-h-12 w-full rounded-md border bg-background px-3 py-2 text-base shadow-sm transition focus-visible:ring-2 disabled:cursor-not-allowed disabled:opacity-50"
                displayValue={(val: string) => {
                  const company = companies.find((u) => u.id === val);
                  return company ? company.name : "";
                }}
              />
              <ComboboxOptions className="border border-border rounded max-h-48 overflow-auto mt-1 bg-popover shadow-lg">
                {filteredCompanies.length === 0 && (
                  <div className="p-2 text-sm text-muted-foreground">
                    No users found
                  </div>
                )}
                {filteredCompanies.map((company) => (
                  <Combobox.Option
                    key={company.id}
                    value={company.id}
                    className="cursor-pointer p-2 hover:bg-accent hover:text-accent-foreground"
                  >
                    {company.name}
                  </Combobox.Option>
                ))}
              </ComboboxOptions>
            </Combobox>
          </div>
        )}

        <form.Field name="senderProtocolNumber">
          {(field) => (
            <div>
              <label className="block text-sm font-medium mb-1 text-muted-foreground">
                Sender Protocol Number
              </label>
              <Input
                placeholder="Sender Protocol Number"
                value={field.state.value}
                onChange={(e) => field.handleChange(e.target.value)}
              />
            </div>
          )}
        </form.Field>

        <form.Field name="senderProtocolDate">
          {(field) => (
            <div>
              <label className="block text-sm font-medium mb-1 text-muted-foreground">
                Sender Protocol Date
              </label>
              <Input
                type="date"
                value={field.state.value?.slice(0, 10)}
                onChange={(e) => field.handleChange(e.target.value)}
              />
            </div>
          )}
        </form.Field>
      </fieldset>

      {/* Letter Details */}
      <fieldset className="space-y-4">
        <legend className="text-lg font-semibold mb-2 text-muted-foreground">
          Letter Details
        </legend>

        <form.Field name="subject">
          {(field) => (
            <div>
              <label className="block text-sm font-medium mb-1 text-muted-foreground">
                Subject
              </label>
              <Input
                placeholder="Subject"
                value={field.state.value}
                onChange={(e) => field.handleChange(e.target.value)}
              />
            </div>
          )}
        </form.Field>

        <form.Field name="body">
          {(field) => (
            <div>
              <label className="block text-sm font-medium mb-1 text-muted-foreground">
                Body
              </label>
              <Textarea
                className="w-full min-h-[120px]"
                placeholder="Write letter body..."
                value={field.state.value}
                onChange={(e) => field.handleChange(e.target.value)}
              />
            </div>
          )}
        </form.Field>

        <form.Field name="receivedDate">
          {(field) => (
            <div>
              <label className="block text-sm font-medium mb-1 text-muted-foreground">
                Received Date
              </label>
              <Input
                type="date"
                value={field.state.value?.slice(0, 10)}
                onChange={(e) => field.handleChange(e.target.value)}
              />
            </div>
          )}
        </form.Field>

        <form.Field name="attachmentBundleLink">
          {(field) => (
            <div>
              <label className="block text-sm font-medium mb-1 text-muted-foreground">
                Attachment Bundle Link
              </label>
              <Input
                placeholder="https://..."
                value={field.state.value}
                onChange={(e) => field.handleChange(e.target.value)}
              />
            </div>
          )}
        </form.Field>
      </fieldset>

      {/* Actions */}
      <div className="flex justify-end gap-4 pt-4">
        <Button variant="outline" onClick={() => router.back()} type="button">
          ← Cancel
        </Button>
        <Button
          type="submit"
          disabled={
            createLetterMutation.isPending || updateLetterMutation.isPending
          }
        >
          {isEditMode ? "Update Letter" : "Create Letter"}
        </Button>
      </div>
    </form>
  );
}
