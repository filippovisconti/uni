// src/components/letters/columns.tsx
"use client";

import { ColumnDef } from "@tanstack/react-table";
import { Letter } from "@/api/data-contracts";
import { Button } from "../ui/button";
import Link from "next/link";

export const letterColumns = (): ColumnDef<Letter>[] => {
  return [
    {
      accessorKey: "protocolNumber",
      header: "Protocol #",
      cell: ({ row }) => <span>{row.original.protocolNumber}</span>,
    },
    {
      accessorKey: "subject",
      header: "Subject",
    },
    {
      accessorKey: "receivedDate",
      header: "Received on",
    },
    {
      accessorKey: "sender.name",
      header: "Sender",
      cell: ({ row }) => {
        const sender = row.original.sender;
        return sender ? <span>{sender.name}</span> : <span className="text-gray-500">Unknown</span>;
      },
    },
    {
      accessorKey: "body",
      header: "Body",
    },
    {
      id: "addWorkItem",
      header: "Actions",
      cell: ({ row }) => {
        const letterId = row.original.id;
        return (
          <Button asChild size="sm">
            <Link href={`/work-items/new?letterId=${letterId}`}>➕ Add Work Item</Link>
          </Button>
        );
      },
    },
  ];
};
