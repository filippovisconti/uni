"use client";

import { useForm } from "@tanstack/react-form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Company } from "@/api/data-contracts";
import { useRouter } from "next/navigation";
import { useCreateCompany, useUpdateCompany } from "@/src/hooks/useData";

type CompanyFormProps = {
  initialData?: Company;
};

export function CompanyForm({ initialData }: CompanyFormProps) {
  const createCompanyMutation = useCreateCompany();
  const updateCompanyMutation = useUpdateCompany();
  const router = useRouter();
  const companyId = initialData?.id;
  const isEditMode = Boolean(companyId);

  async function onSubmit(values: Company) {
    try {
      if (isEditMode) {
        await updateCompanyMutation.mutateAsync({
          id: companyId!,
          body: values,
        });
      } else {
        await createCompanyMutation.mutateAsync(values);
      }

      router.push("/companies");
    } catch (error) {
      console.error("Failed to submit:", error);
    }
  }
  const form = useForm({
    defaultValues: initialData || {
      name: "",
      contactEmail: "",
      contactPhone: "",
      address: {
        street: "",
        houseNumber: "",
        city: "",
        province: "",
        postalCode: "",
        country: "",
      },
    },
    onSubmit: async ({ value }) => {
      await onSubmit(value);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault(); // ✅ prevent default form behavior
    form.handleSubmit(); // ✅ call form submit handler
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-6">
      <h1 className="text-xl font-bold">{isEditMode ? "Edit Company" : "New Company"}</h1>

      <form.Field name="name">
        {(field) => (
          <Input
            value={field.state.value}
            onChange={(e) => field.handleChange(e.target.value)}
            placeholder="Name"
          />
        )}
      </form.Field>

      <form.Field name="contactEmail">
        {(field) => (
          <Input
            value={field.state.value as string | undefined}
            onChange={(e) => field.handleChange(e.target.value)}
            placeholder="Email"
          />
        )}
      </form.Field>

      <form.Field name="contactPhone">
        {(field) => (
          <Input
            value={field.state.value as string | undefined}
            onChange={(e) => field.handleChange(e.target.value)}
            placeholder="Phone"
          />
        )}
      </form.Field>

      <fieldset className="border p-4 space-y-2">
        <legend className="text-sm font-semibold">Address</legend>

        <form.Field name="address.street">
          {(field) => (
            <Input
              value={field.state.value}
              onChange={(e) => field.handleChange(e.target.value)}
              placeholder="Street"
            />
          )}
        </form.Field>

        <form.Field name="address.houseNumber">
          {(field) => (
            <Input
              value={field.state.value}
              onChange={(e) => field.handleChange(e.target.value)}
              placeholder="House No."
            />
          )}
        </form.Field>

        <form.Field name="address.city">
          {(field) => (
            <Input
              value={field.state.value}
              onChange={(e) => field.handleChange(e.target.value)}
              placeholder="City"
            />
          )}
        </form.Field>

        <form.Field name="address.province">
          {(field) => (
            <Input
              value={field.state.value}
              onChange={(e) => field.handleChange(e.target.value)}
              placeholder="Province"
            />
          )}
        </form.Field>

        <form.Field name="address.postalCode">
          {(field) => (
            <Input
              value={field.state.value}
              onChange={(e) => field.handleChange(e.target.value)}
              placeholder="Postal Code"
            />
          )}
        </form.Field>

        <form.Field name="address.country">
          {(field) => (
            <Input
              value={field.state.value}
              onChange={(e) => field.handleChange(e.target.value)}
              placeholder="Country"
            />
          )}
        </form.Field>
      </fieldset>
      <div className="flex gap-4">
        <Button variant="secondary" onClick={() => router.back()}>
          ← Back
        </Button>
        <Button
          type="submit"
          disabled={createCompanyMutation.isPending || updateCompanyMutation.isPending}
        >
          {isEditMode ? "Update Company" : "Create Company"}
        </Button>
      </div>
    </form>
  );
}
