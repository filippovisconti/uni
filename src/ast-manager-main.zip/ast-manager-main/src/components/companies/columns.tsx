"use client";

import { ColumnDef } from "@tanstack/react-table";
import { Company } from "@/api/data-contracts";

export const columns = (): ColumnDef<Company>[] => [
  {
    accessorKey: "name",
    header: "Company Name",
    cell: ({ row }) => {
      const company = row.original;
      return <span className="font-bold">{company.name}</span>;
    },
  },
  {
    accessorKey: "contactEmail",
    header: "Contact Email",
  },
  {
    accessorKey: "contactPhone",
    header: "Phone",
  },
  {
    accessorKey: "address.city",
    header: "City",
    cell: ({ row }) => row.original.address?.city || "-",
  },
  {
    accessorKey: "address.country",
    header: "Country",
    cell: ({ row }) => row.original.address?.country || "-",
  },
];
