import { workItemColumns } from "@/src/components/work-items/WorkItemsColumns";
import { DataTable } from "@/components/ui/DataTable";
import { notFound, useRouter } from "next/navigation";

import {
  useDeleteWorkItem,
  useGetWorkItems,
  useGetWorkItemsWithFilters,
} from "@/src/hooks/useWorkItems";

interface WorkItemsTableProps {
  filters?: {
    assigneeId?: string;
    projectId?: string;
    companyId?: string;
    state?: number;
  };
}

export default function WorkItemsTable({ filters }: WorkItemsTableProps) {
  const router = useRouter();

  const { data, isLoading, error } = filters
    ? useGetWorkItemsWithFilters(filters)
    : useGetWorkItems();
  const deleteWorkItem = useDeleteWorkItem();
  if (isLoading) return <p className="p-4">Loading work items...</p>;
  if (!data) {
    return notFound();
  }
  if (data.length === 0) {
    return <p>No work items found</p>;
  }
  if (error) return <p className="p-4 text-red-500">Error loading work items</p>;

  const columns = workItemColumns();
  return (
    <DataTable
      columns={columns}
      data={data}
      // minCellWidth="120px"
      onRowClick={(row) => router.push(`/work-items/${row.id}`)}
      onRowEdit={(row) => router.push(`/work-items/${row.id}/edit`)}
      onRowDelete={(row) =>
        new Promise<void>((resolve, reject) => {
          deleteWorkItem.mutate(row.id!, {
            onSuccess: () => resolve(),
            onError: () => reject(),
          });
        })
      }
    />
  );
}
