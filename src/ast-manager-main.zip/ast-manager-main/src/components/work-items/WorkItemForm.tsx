"use client";

import { useForm } from "@tanstack/react-form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import { CreateWorkItemDto, User, Letter, Project, WorkItem } from "@/api/data-contracts";
import { EntityPicker } from "../EntityPicker";
import { useCreateWorkItem, useUpdateWorkItem } from "@/src/hooks/useWorkItems";
import { workItemStateMeta } from "@/src/lib/utils";

type WorkItemFormProps = {
  initialData?: WorkItem;
  users: User[];
  letters: Letter[];
  projects: Project[];
};

export function WorkItemForm({ initialData, users, letters, projects }: WorkItemFormProps) {
  const router = useRouter();
  const workItemId = initialData?.id;
  const isEditMode = Boolean(workItemId);

  const createWorkItemMutation = useCreateWorkItem();
  const updateWorkItemMutation = useUpdateWorkItem();
  const stateOptions = Object.entries(workItemStateMeta).map(([value, meta]) => ({
    label: meta.label,
    value,
  }));
  async function onSubmit(values: CreateWorkItemDto) {
    try {
      if (isEditMode) {
        await updateWorkItemMutation.mutateAsync({
          id: workItemId!,
          data: values,
        });
      } else {
        await createWorkItemMutation.mutateAsync(values);
      }
      // router.back()
      router.push("/work-items");
    } catch (error) {
      console.error("Failed to submit work item:", error);
    }
  }

  const form = useForm({
    defaultValues: initialData || {
      creationDate: new Date().toISOString(),
      currentState: 0,
      archivalDate: null,
      assignmentDate: new Date().toISOString(),
      assignmentNotes: "",
      assigneeId: "",
      assignedById: "",
      letterId: "",
      projectId: null,
    },
    onSubmit: async ({ value }) => {
      const normalizedValue: CreateWorkItemDto = {
        ...value,
        assignmentDate: value.assignmentDate ?? new Date().toISOString(),
        creationDate: value.creationDate ?? new Date().toISOString(),
        archivalDate: value.archivalDate ?? null,
        assignmentNotes: value.assignmentNotes ?? "",
        assigneeId: value.assigneeId ?? "",
        assignedById: value.assignedById ?? "",
        letterId: value.letterId ?? "",
        projectId: value.projectId ?? null,
        currentState: value.currentState ?? 0,
      };
      // ensure dates are in ISO format
      if (normalizedValue.assignmentDate) {
        normalizedValue.assignmentDate = new Date(normalizedValue.assignmentDate).toISOString();
      }
      if (normalizedValue.creationDate) {
        normalizedValue.creationDate = new Date(normalizedValue.creationDate).toISOString();
      }
      if (normalizedValue.archivalDate) {
        normalizedValue.archivalDate = new Date(normalizedValue.archivalDate).toISOString();
      } else {
        normalizedValue.archivalDate = null;
      }
      await onSubmit(normalizedValue);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    form.handleSubmit();
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="space-y-6 p-6 m-6 w-2xl mx-auto bg-background shadow rounded-xl border border-border"
    >
      <h1 className="text-xl font-bold text-foreground">
        {isEditMode ? "Edit Work Item" : "New Work Item"}
      </h1>

      <fieldset className="space-y-4">
        <legend className="text-lg font-semibold mb-2 text-foreground">
          Assignment Information
        </legend>

        <form.Field name="assignmentDate">
          {(field) => (
            <div>
              <label className="block text-sm font-medium mb-1 text-muted-foreground">
                Assignment Date
              </label>
              <Input
                type="datetime-local"
                value={field.state.value?.slice(0, 16) ?? ""}
                onChange={(e) => field.handleChange(e.target.value)}
                placeholder="Assignment Date"
              />
            </div>
          )}
        </form.Field>

        <form.Field name="assignmentNotes">
          {(field) => (
            <div>
              <label className="block text-sm font-medium mb-1 text-muted-foreground">
                Assignment Notes
              </label>
              <Input
                value={field.state.value}
                onChange={(e) => field.handleChange(e.target.value)}
                placeholder="Assignment Notes"
              />
            </div>
          )}
        </form.Field>

        <form.Field name="assigneeId">
          {(field) => (
            <div>
              <label className="block text-sm font-medium mb-1">Assignee</label>
              <EntityPicker
                label="Assignee"
                options={users
                  .filter((u): u is User & { id: string } => !!u.id)
                  .map((u) => ({
                    label: `${u.firstName} ${u.lastName}`,
                    value: u.id,
                  }))}
                value={field.state.value}
                onChange={(id) => field.handleChange(id)}
              />
            </div>
          )}
        </form.Field>

        <form.Field name="assignedById">
          {(field) => (
            <div>
              <label className="block text-sm font-medium mb-1">Assigned By</label>
              <EntityPicker
                label="Assigned By"
                options={users
                  .filter((u): u is User & { id: string } => !!u.id)
                  .map((u) => ({
                    label: `${u.firstName} ${u.lastName}`,
                    value: u.id,
                  }))}
                value={field.state.value}
                onChange={(id) => field.handleChange(id)}
              />
            </div>
          )}
        </form.Field>
      </fieldset>

      <fieldset className="space-y-4">
        <form.Field name="letterId">
          {(field) => (
            <div>
              <label className="block text-sm font-medium mb-1">Letter Protocol Number</label>
              <EntityPicker
                label="Letter"
                options={letters
                  .filter((l): l is Letter & { id: string } => !!l.id)
                  .map((l) => ({
                    label: `${l.subject} (${l.protocolNumber})`,
                    value: l.id,
                  }))}
                value={field.state.value}
                onChange={(id) => field.handleChange(id)}
              />
            </div>
          )}
        </form.Field>

        <form.Field name="projectId">
          {(field) => (
            <div>
              <label className="block text-sm font-medium mb-1">Project</label>
              <EntityPicker
                label="Project"
                options={projects
                  .filter((p): p is Project & { id: string } => !!p.id)
                  .map((p) => ({
                    label: p.name,
                    value: p.id,
                  }))}
                value={field.state.value ?? ""}
                onChange={(id) => field.handleChange(id)}
              />
            </div>
          )}
        </form.Field>
      </fieldset>

      <form.Field name="currentState">
        {(field) => (
          <div>
            <label className="block text-sm font-medium mb-1 text-muted-foreground">
              Current State
            </label>
            <EntityPicker
              label="State"
              options={stateOptions}
              value={String(field.state.value ?? "")}
              onChange={(val) => field.handleChange(parseInt(val))}
            />
          </div>
        )}
      </form.Field>
      {/* if edit mode on, enable hidden creationDate field with todays date */}
      {isEditMode && (
        <form.Field name="creationDate">
          {(field) => (
            <Input
              type="hidden"
              value={field.state.value ?? new Date().toISOString()}
              onChange={(e) => field.handleChange(e.target.value)}
            />
          )}
        </form.Field>
      )}
      {isEditMode && (
        <form.Field name="archivalDate">
          {(field) => (
            <div>
              <label className="block text-sm font-medium mb-1 text-muted-foreground">
                Archival Date
              </label>
              <Input
                type="date"
                value={field.state.value?.slice(0, 10) ?? ""}
                onChange={(e) => field.handleChange(e.target.value)}
              />
            </div>
          )}
        </form.Field>
      )}

      <div className="flex gap-4">
        <Button variant="secondary" type="button" onClick={() => router.back()}>
          ← Back
        </Button>
        <Button
          type="submit"
          disabled={
            createWorkItemMutation.isPending || updateWorkItemMutation.isPending
          }
        >
          {isEditMode ? "Update Work Item" : "Create Work Item"}
        </Button>
      </div>
    </form>
  );
}
