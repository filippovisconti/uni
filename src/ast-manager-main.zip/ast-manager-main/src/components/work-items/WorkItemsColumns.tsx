import { ColumnDef, FilterFn } from "@tanstack/react-table";
import { WorkItem } from "@/api/data-contracts";
import Link from "next/link";
import { WorkItemState, workItemStateMeta } from "@/src/lib/utils";
import { Fragment, useState } from "react";
import {
  Menu,
  MenuButton,
  MenuItem,
  MenuItems,
  Transition,
} from "@headlessui/react";

const multiSelectFilter: FilterFn<any> = (
  row,
  columnId,
  filterValue: WorkItemState[]
) => {
  if (!filterValue || filterValue.length === 0) return true; // Show all rows
  const rowValue = row.getValue(columnId);
  return filterValue.includes(rowValue as WorkItemState);
};

export const workItemColumns = (): ColumnDef<WorkItem>[] => {
  const linkStyle = "hover:text-blue-600 underline";
  return [
    {
      header: "Protocol #",
      accessorKey: "letter.protocolNumber",
      cell: ({ row }) => {
        const letter = row.original.letter;
        return letter ? (
          <Link href={`/letters/${letter.id}`} className={linkStyle}>
            {letter.protocolNumber}
          </Link>
        ) : (
          "-"
        );
      },
    },
    {
      header: "Prot. Date",
      accessorKey: "letter.protocolDate",
      cell: ({ row }) => {
        const letter = row.original.letter;
        return letter && letter.protocolDate
          ? new Date(letter.protocolDate).toLocaleDateString()
          : "-";
      },
    },
    {
      header: "Company Name",
      accessorKey: "letter.sender.name",
      cell: ({ row }) => {
        const company = row.original.letter?.sender;
        return company ? (
          <Link href={`/companies/${company.id}`} className={linkStyle}>
            {company.name}
          </Link>
        ) : (
          "-"
        );
      },
    },

    {
      header: "Assignee",
      accessorKey: "assignee.firstName",
      cell: ({ row }) => {
        const user = row.original.assignee;
        return user ? (
          <Link href={`/users/${user.id}`} className={linkStyle}>
            {user.firstName} {user.lastName}
          </Link>
        ) : (
          "-"
        );
      },
    },
    // {
    //   header: "Assigned By",
    //   accessorKey: "assignedBy.firstName",
    //   cell: ({ row }) => {
    //     const user = row.original.assignedBy;
    //     return user ? (
    //       <Link href={`/users/${user.id}`} className={linkStyle}>
    //         {user.firstName} {user.lastName}
    //       </Link>
    //     ) : (
    //       "-"
    //     );
    //   },
    // },

    {
      header: "Assigned On",
      accessorKey: "assignmentDate",
      cell: ({ row }) => {
        if (!row.original.assignmentDate) return "Not Assigned";
        return new Date(row.original.assignmentDate).toLocaleDateString();
      },
    },
    {
      header: "Assignment Detailed Notes",
      accessorKey: "assignmentNotes",
    },
    {
      header: "Project Name",
      accessorKey: "project.name",
      cell: ({ row }) => {
        const project = row.original.project;
        return project ? (
          <Link href={`/projects/${project.id}`} className={linkStyle}>
            {project.name}
          </Link>
        ) : (
          "-"
        );
      },
    },
    // {
    //   header: "Letter Body Text",
    //   accessorKey: "letter.body",
    //   cell: ({ row }) => {
    //     const letter = row.original.letter;
    //     return letter ? (
    //       <Link href={`/letters/${letter.id}`} className={linkStyle}>
    //         {letter.body ? letter.body.slice(0, 50) + "..." : "No body content"}
    //       </Link>
    //     ) : (
    //       "-"
    //     );
    //   },
    // },
    {
      header: "Letter Subject",
      accessorKey: "letter.subject",
      cell: ({ row }) => {
        const letter = row.original.letter;
        return letter ? (
          <Link href={`/letters/${letter.id}`} className={linkStyle}>
            {letter.subject}
          </Link>
        ) : (
          "-"
        );
      },
    },
    {
      id: "currentState",
      header: ({ column }) => {
        const [selected, setSelected] = useState<WorkItemState[]>([]);

        const toggleState = (state: WorkItemState) => {
          const newSelected = selected.includes(state)
            ? selected.filter((s) => s !== state)
            : [...selected, state];
          setSelected(newSelected);
          column.setFilterValue(newSelected);
        };

        return (
          <Menu as="div" className="relative inline-block text-left">
            <MenuButton
              className={`inline-flex justify-center w-full rounded-md border shadow-sm px-2 mb-8.5 text-sm font-medium
    ${selected.length > 0 ? "bg-blue-100 text-blue-800 border-blue-300" : "bg-white text-gray-700 hover:bg-gray-50"}
  `}
            >
              {selected.length > 0
                ? `Current State (${selected.length})`
                : "Current State (0)"}
            </MenuButton>

            <Transition
              as={Fragment}
              enter="transition ease-out duration-100"
              enterFrom="transform opacity-0 scale-95"
              enterTo="transform opacity-100 scale-100"
              leave="transition ease-in duration-75"
              leaveFrom="transform opacity-100 scale-100"
              leaveTo="transform opacity-0 scale-95"
            >
              <MenuItems className="absolute z-10 mt-1 w-56 origin-top-left rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                <div className="py-1 max-h-60 overflow-auto">
                  {Object.entries(workItemStateMeta).map(([key, meta]) => {
                    const state = Number(key) as WorkItemState;
                    return (
                      <MenuItem key={key}>
                        {({ active }) => (
                          <label
                            className={`
                          flex items-center gap-2 px-3 py-1 text-sm cursor-pointer
                          ${active ? "bg-gray-100" : ""}
                        `}
                          >
                            <input
                              type="checkbox"
                              checked={selected.includes(state)}
                              onChange={() => toggleState(state)}
                            />
                            <span
                              className={`inline-block px-2 py-1 rounded text-xs font-semibold ${meta.color}`}
                            >
                              {meta.label}
                            </span>
                          </label>
                        )}
                      </MenuItem>
                    );
                  })}
                </div>
              </MenuItems>
            </Transition>
          </Menu>
        );
      },
      accessorFn: (row) => row.currentState ?? -1,
      cell: ({ row }) => {
        const state = row.original.currentState;
        if (state === undefined || state === null) return "—";

        const label =
          workItemStateMeta[state as WorkItemState]?.label ?? "Unknown";
        const color =
          workItemStateMeta[state as WorkItemState]?.color ??
          "bg-white text-black";

        return (
          <div className={` ${color} flex justify-center items-center`}>
            <span className="text-xs font-semibold">{label}</span>
          </div>
        );
      },
      enableSorting: false,
      enableColumnFilter: false,
      filterFn: multiSelectFilter,
    },
    // {
    //   header: "Creation Date",
    //   accessorKey: "creationDate",
    //   cell: ({ row }) => {
    //     if (!row.original.creationDate) return "—";
    //     return new Date(row.original.creationDate).toLocaleDateString();
    //   },
    // },
    {
      header: "Archival Date",
      accessorKey: "archivalDate",
      cell: ({ row }) => {
        if (!row.original.archivalDate) return "—";
        return new Date(row.original.archivalDate).toLocaleDateString();
      },
    },
  ];
};
