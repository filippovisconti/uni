"use client";

import { createContext, useContext, useEffect, useState } from "react";

const HeaderTitleContext = createContext<{
  title: string;
  setTitle: (title: string) => void;
}>({
  title: "",
  setTitle: () => {},
});

export function HeaderTitleProvider({ children }: { children: React.ReactNode }) {
  const [title, setTitle] = useState("");
  return (
    <HeaderTitleContext.Provider value={{ title, setTitle }}>
      {children}
    </HeaderTitleContext.Provider>
  );
}

export function useHeaderTitle() {
  return useContext(HeaderTitleContext);
}

export function SetDefaultHeaderTitle({ title }: { title: string }) {
  const { setTitle } = useHeaderTitle();

  useEffect(() => {
    setTitle(title);
  }, [title, setTitle]);

  return null;
}
