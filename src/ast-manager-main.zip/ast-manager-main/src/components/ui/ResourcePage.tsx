"use client";

import { DataTable } from "@/components/ui/DataTable";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { useRouter } from "next/navigation";

type ResourcePageProps<T extends { id?: string }> = {
  title: string;
  newPath: string;
  getHook: () => { data: T[] | undefined; isLoading: boolean; error: unknown };
  deleteHook: () => {
    mutate: (
      id: string,
      opts: { onSuccess: () => void; onError: () => void }
    ) => void;
  };
  columns: () => any;
  basePath: string;
};

export function ResourcePage<T extends { id?: string }>({
  title,
  newPath,
  getHook,
  deleteHook,
  columns,
  basePath,
}: ResourcePageProps<T>) {
  const { data, isLoading, error } = getHook();
  const deleteMutation = deleteHook();
  const router = useRouter();

  if (isLoading) return <p className="p-4">Loading {title.toLowerCase()}...</p>;
  if (error)
    return (
      <p className="p-4 text-red-500">Failed to load {title.toLowerCase()}.</p>
    );
  if (!data || data.length === 0) {
    return (
      <div className="p-6 space-y-4">
        <div className="flex justify-between items-center">
          <h1 className="text-xl font-bold">{title}</h1>
          <Link href={newPath}>
            <Button>
              Add {title === "Companies" ? "Company" : title.slice(0, -1)}
            </Button>
          </Link>
        </div>
        <p className="text-gray-500">No {title.toLowerCase()} found.</p>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-xl font-bold">{title}</h1>
        <Link href={newPath}>
          <Button>
            Add {title === "Companies" ? "Company" : title.slice(0, -1)}
          </Button>
        </Link>
      </div>
      <DataTable
        columns={columns()}
        data={data}
        onRowClick={(row) => router.push(`${basePath}/${row.id}`)}
        onRowEdit={(row) => router.push(`${basePath}/${row.id}/edit`)}
        onRowDelete={(row) =>
          new Promise<void>((resolve, reject) => {
            deleteMutation.mutate(row.id!, {
              onSuccess: () => resolve(),
              onError: () => reject(),
            });
          })
        }
      />
    </div>
  );
}
