"use client";

import {
  flexRender,
  getCoreRowModel,
  getSortedRowModel,
  getFilteredRowModel,
  useReactTable,
  ColumnDef,
  SortingState,
  ColumnFiltersState,
  FilterFn,
} from "@tanstack/react-table";
import { rankItem } from "@tanstack/match-sorter-utils";
import { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { ContextMenuWrapper } from "../ContextMenuWrapper";

// fuzzy filter function
const fuzzyFilter: FilterFn<any> = (row, columnId, value, addMeta) => {
  const rowValue = row.getValue(columnId);

  // Safely convert undefined/null to empty string
  const safeValue = rowValue == null ? "" : String(rowValue);

  const itemRank = rankItem(safeValue, value);
  addMeta?.({ itemRank });
  return itemRank.passed;
};

export function DataTable<TData, TValue>({
  columns,
  data,
  onRowClick,
  onRowEdit,
  onRowDelete,
  isDeleting,
  // minCellWidth = "50px",
  // maxCellWidth = "100px",
}: {
  columns: ColumnDef<TData, TValue>[];
  data: TData[];
  onRowClick?: (row: TData) => void;
  onRowEdit: (row: TData) => void;
  onRowDelete: (row: TData) => Promise<void> | void;
  isDeleting?: boolean;
  // minCellWidth?: string;
  // maxCellWidth?: string;
}) {
  const [sorting, setSorting] = useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);

  const table = useReactTable({
    data,
    columns,
    state: { sorting, columnFilters },
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    filterFns: {
      fuzzy: fuzzyFilter,
    },
  });

  return (
    <div className="rounded-xl border border-border shadow-sm overflow-hidden bg-background">
      <div className="overflow-x-auto">
        <Table className="w-full text-sm text-foreground">
          <TableHeader className="bg-muted/50">
            {table.getHeaderGroups().map((hg) => (
              <TableRow key={hg.id}>
                {hg.headers.map((header) => (
                  <TableHead
                    key={header.id}
                    className="px-4 py-2 text-left text-sm font-semibold"
                  >
                    <div
                      onClick={header.column.getToggleSortingHandler()}
                      className="flex items-center gap-1 cursor-pointer select-none hover:text-primary"
                    >
                      {flexRender(
                        header.column.columnDef.header,
                        header.getContext()
                      )}
                      {{
                        asc: "↑",
                        desc: "↓",
                      }[header.column.getIsSorted() as string] ?? null}
                    </div>
                    {header.column.getCanFilter() && (
                      <Input
                        value={(header.column.getFilterValue() ?? "") as string}
                        onChange={(e) =>
                          header.column.setFilterValue(e.target.value)
                        }
                        placeholder="Filter..."
                        className="mt-1 h-8"
                      />
                    )}
                  </TableHead>
                ))}
              </TableRow>
            ))}
          </TableHeader>

          <TableBody>
            {table.getRowModel().rows.map((row, index) => (
              <ContextMenuWrapper
                key={row.id}
                row={row.original}
                onEdit={() => onRowEdit?.(row.original)}
                onDelete={() => onRowDelete(row.original)}
                isDeleting={isDeleting}
                entityName="item"
              >
                <TableRow
                  className={`cursor-pointer transition hover:bg-muted/70 ${
                    index % 2 === 0 ? "bg-background" : "bg-muted/40"
                  }`}
                  onClick={(e) => {
                    const target = e.target as HTMLElement;
                    if (
                      target.closest(
                        "a, button, input, textarea, select, [role='button']"
                      )
                    )
                      return;
                    if (!target.closest("td")) return;
                    onRowClick?.(row.original);
                  }}
                >
                  {row.getVisibleCells().map((cell) => (
                    <TableCell
                      key={cell.id}
                      className="px-4 py-3 align-top"
                      style={{
                        // minWidth: minCellWidth,
                        // maxWidth: maxCellWidth,
                        whiteSpace: "normal",
                        wordBreak: "break-word",
                      }}
                    >
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              </ContextMenuWrapper>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
