"use client";

import * as React from "react";
import { Area, AreaChart, CartesianGrid, XAxis } from "recharts";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  ChartConfig,
  ChartContainer,
  ChartLegend,
  ChartLegendContent,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import { format, parseISO, subDays } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import { useGetWorkItems } from "@/src/hooks/useWorkItems";

const chartConfig = {
  newWorkItems: {
    label: "New Work Items",
    color: "var(--chart-1)",
  },
} satisfies ChartConfig;

export function ChartWorkItemsCreated() {
  const [timeRange, setTimeRange] = React.useState("90d");

  const { data: workItems, isLoading, error } = useGetWorkItems();

  // Prepare chart data
  const chartData = React.useMemo(() => {
    if (!workItems) return [];

    const countsByDay: Record<string, number> = {};

    for (const item of workItems) {
      const createdAt = item.creationDate || item.assignmentDate;
      if (!createdAt) continue;

      const dateStr = format(new Date(createdAt), "yyyy-MM-dd");
      countsByDay[dateStr] = (countsByDay[dateStr] || 0) + 1;
    }

    const today = new Date();
    const rangeDays = timeRange === "7d" ? 7 : timeRange === "30d" ? 30 : 90;
    const startDate = subDays(today, rangeDays);

    const result: { date: string; newWorkItems: number }[] = [];

    for (let i = 0; i <= rangeDays; i++) {
      const date = format(subDays(today, rangeDays - i), "yyyy-MM-dd");
      result.push({ date, newWorkItems: countsByDay[date] || 0 });
    }

    return result;
  }, [workItems, timeRange]);

  if (isLoading) {
    return (
      <Card className="p-6 space-y-2">
        <Skeleton className="h-6 w-[240px]" />
        <Skeleton className="h-4 w-[300px]" />
        <Skeleton className="h-[250px] w-full" />
      </Card>
    );
  }

  if (error || !workItems) {
    return (
      <Card className="p-6">
        <CardTitle>Error</CardTitle>
        <CardDescription>Failed to load work items data.</CardDescription>
      </Card>
    );
  }

  return (
    <Card className="pt-0">
      <CardHeader className="flex items-center gap-2 space-y-0 border-b py-5 sm:flex-row">
        <div className="grid flex-1 gap-1">
          <CardTitle>New Work Items</CardTitle>
          <CardDescription>Work items created per day</CardDescription>
        </div>
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger
            className="hidden w-[160px] rounded-lg sm:ml-auto sm:flex"
            aria-label="Select time range"
          >
            <SelectValue placeholder="Last 90 days" />
          </SelectTrigger>
          <SelectContent className="rounded-xl">
            <SelectItem value="90d" className="rounded-lg">
              Last 90 days
            </SelectItem>
            <SelectItem value="30d" className="rounded-lg">
              Last 30 days
            </SelectItem>
            <SelectItem value="7d" className="rounded-lg">
              Last 7 days
            </SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>

      <CardContent className="px-2 pt-4 sm:px-6 sm:pt-6">
        <ChartContainer
          config={chartConfig}
          className="aspect-auto h-[250px] w-full"
        >
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="fillWorkItems" x1="0" y1="0" x2="0" y2="1">
                <stop
                  offset="5%"
                  stopColor="var(--color-newWorkItems)"
                  stopOpacity={0.8}
                />
                <stop
                  offset="95%"
                  stopColor="var(--color-newWorkItems)"
                  stopOpacity={0.1}
                />
              </linearGradient>
            </defs>

            <CartesianGrid vertical={false} />
            <XAxis
              dataKey="date"
              tickLine={false}
              axisLine={false}
              tickMargin={8}
              minTickGap={32}
              tickFormatter={(value) => format(parseISO(value), "MMM d")}
            />
            <ChartTooltip
              cursor={false}
              content={
                <ChartTooltipContent
                  labelFormatter={(value) =>
                    format(parseISO(value), "MMM d, yyyy")
                  }
                  indicator="dot"
                />
              }
            />
            <Area
              dataKey="newWorkItems"
              type="natural"
              fill="url(#fillWorkItems)"
              stroke="var(--color-newWorkItems)"
              stackId="a"
            />
            <ChartLegend content={<ChartLegendContent />} />
          </AreaChart>
        </ChartContainer>
      </CardContent>
    </Card>
  );
}
