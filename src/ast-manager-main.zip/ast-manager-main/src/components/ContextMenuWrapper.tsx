// src/components/common/ContextMenuWrapper.tsx
"use client";

import {
  ContextMenu,
  ContextMenuTrigger,
  ContextMenuContent,
  ContextMenuItem,
} from "@/components/ui/context-menu";
import { ReactNode } from "react";
import { toast } from "sonner";

type ContextMenuWrapperProps<T> = {
  row: T;
  children: ReactNode;
  onEdit?: (row: T) => void;
  onDelete?: (row: T) => Promise<void> | void;
  isDeleting?: boolean;
  entityName?: string;
};

export function ContextMenuWrapper<T>({
  row,
  children,
  onEdit,
  onDelete,
  isDeleting,
  entityName = "item",
}: ContextMenuWrapperProps<T>) {
  const handleEdit = () => {
    if (onEdit) onEdit(row);
  };

  const handleDelete = async () => {
    const confirmed = window.confirm(
      `Are you sure you want to delete this ${entityName}? This action cannot be undone.`,
    );
    if (!confirmed) return;

    try {
      await onDelete?.(row);
      toast.success(`${capitalize(entityName)} deleted`);
    } catch {
      toast.error(`Failed to delete ${entityName}`);
    }
  };

  return (
    <ContextMenu>
      <ContextMenuTrigger asChild>{children}</ContextMenuTrigger>
      <ContextMenuContent>
        {onEdit && <ContextMenuItem onClick={handleEdit}>Edit</ContextMenuItem>}
        {onDelete && (
          <ContextMenuItem onClick={handleDelete} disabled={isDeleting} className="text-red-600">
            {isDeleting ? "Deleting..." : "Delete"}
          </ContextMenuItem>
        )}
      </ContextMenuContent>
    </ContextMenu>
  );
}

function capitalize(str: string) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}
