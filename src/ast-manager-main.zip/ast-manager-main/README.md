# 📁 AST Manager — README

## 📌 Overview

This is a **Next.js 13+** application using the **App Router** with a modular, feature-first architecture.
It contains entity-specific CRUD pages, a UI design system, custom hooks for data fetching, and a typed API client layer.

---

## 🗂 Directory Structure

```plaintext
src
├── app                     # App Router entry points
│   ├── (details)           # Grouped entity CRUD pages
│   │   ├── companies       # CRUD pages for companies
│   │   ├── letters         # CRUD pages for letters
│   │   ├── meetings        # CRUD pages for meetings
│   │   ├── projects        # CRUD pages for projects
│   │   ├── users           # CRUD pages for users
│   │   └── work-items      # CRUD pages for work items
│   ├── api                 # API client, contracts, and HTTP helper
│   ├── dashboard           # Dashboard overview
│   ├── search              # Search page
│   ├── layout.tsx          # Root layout
│   ├── page.tsx            # Landing page
│   └── globals.css         # Global styles
│
├── components              # Reusable components
│   ├── cards               # Card display components
│   ├── ui                  # Generic UI building blocks
│   ├── companies           # Company-specific forms & tables
│   ├── letters             # Letter-specific forms & tables
│   ├── meetings            # Meeting-specific forms & tables
│   ├── projects            # Project-specific forms & tables
│   ├── users               # User-specific forms & tables
│   └── work-items          # Work-item-specific forms & tables
│
├── hooks                   # Custom React hooks
├── lib                     # Utilities
└── providers               # App-level providers (React Query)
```

---

## 🗺 Architecture Overview

```mermaid
flowchart TD
    subgraph USER[User Interaction]
        UI["UI: Forms, Tables, Buttons"]
    end

    subgraph COMPONENTS[Components Layer]
        DC["Domain Components(/companies, /letters, /projects, etc.)"]
        UC["UI Components(/ui)"]
    end

    subgraph HOOKS[Hooks Layer]
        HD["useData / usePartialData"]
        HE["Entity-specific hooks(useLetters, useWorkItems)"]
    end

    subgraph API[API Client Layer]
        CL["apiClient.ts"]
        HT["http-client.ts"]
        DT["data-contracts.ts"]
    end

    subgraph BACKEND[External API Backend]
        APIB["REST"]
    end

    UI --> DC
    UI --> UC
    DC --> HD
    UC --> HD
    HD --> HE
    HE --> CL
    CL --> HT
    CL --> DT
    HT --> APIB

```

**Flow Summary:**

1. **User** interacts with UI (forms, tables, buttons).
2. **Components** trigger data operations via custom hooks.
3. **Hooks** use React Query to fetch/mutate data.
4. **API Client** handles request building, typing, and HTTP calls.
5. **Backend API** returns data → React Query caches & updates UI.

---

## 🚀 Getting Started

### Install Dependencies

```bash
pnpm install
# or
npm install
# or
yarn install
```

### Set Environment Variables

Create `.env.local`:

```env
NEXT_PUBLIC_API_BASE_URL=https://your-api.com
```

### Run Development Server

```bash
pnpm dev
# or
npm run dev
# or
yarn dev
```

Visit: **[http://localhost:3000](http://localhost:3000)**

---

## 📦 Features

* **Entity CRUD**: Companies, Letters, Meetings, Projects, Users, Work Items.
* **UI Design System**: Buttons, Inputs, Cards, Tables, Modals, Charts.
* **Dashboard & Search**: KPI charts, global search.
* **API Integration**: Typed contracts, centralized HTTP client.
* **Hooks for Data**: useData, usePartialData, entity-specific hooks.

---

## 📜 Scripts

```bash
pnpm dev        # Start dev server
pnpm build      # Production build
pnpm start      # Start prod server
pnpm lint       # Lint code
```

---

## 🛠 Tech Stack

* **Next.js 13+ App Router**
* **TypeScript**
* **Tailwind CSS**
* **React Query**
* **TanStack Table**
* **Custom Charts**

---

## 📖 Conventions

* **Folder-by-feature** for clarity & scalability.
* **UI vs Domain Components** separation.
* **All API Types** in `data-contracts.ts`.
