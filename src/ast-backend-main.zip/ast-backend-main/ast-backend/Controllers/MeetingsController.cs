using ast_backend.DTOs;
using ast_backend.Models;
using ast_backend.Persistence;
using ast_backend.Services.Validation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ast_backend.Controllers;

[ApiController]
[Route("api/[controller]")]
public class MeetingsController(
    AppDbContext context,
    ILogger<MeetingsController> logger,
    IMeetingValidator validator
) : ControllerBase
{
    private readonly AppDbContext _context = context;

    private readonly ILogger<MeetingsController> _logger = logger;
    private readonly IMeetingValidator _validator = validator;

    [HttpPost]
    public async Task<IActionResult> CreateMeeting([FromBody] MeetingDto dto)
    {
        var meeting = new Meeting
        {
            Id = Guid.NewGuid(),
            Date = dto.Date.ToUniversalTime(),
            Location = dto.Location,
            Summary = dto.Summary,
            ResourceUrl = dto.ResourceUrl,
            ProjectId = dto.ProjectId,
            ParticipantCompanyIds = dto.ParticipantCompanyIds,
        };

        var (isValid, errorMessage) = _validator.ValidateNewMeeting(meeting);
        if (!isValid)
        {
            _logger.LogWarning("CreateMeeting: {Error}", errorMessage);
            return BadRequest(errorMessage);
        }
        var (referencesValid, referenceError) = await _validator.ValidateReferencesAsync(meeting);
        if (!referencesValid)
        {
            _logger.LogWarning("CreateMeeting: {Error}", referenceError);
            return BadRequest(referenceError);
        }
        try
        {
            _context.Meetings.Add(meeting);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Meeting created successfully with ID {Id}", meeting.Id);
            return CreatedAtAction(nameof(GetMeeting), new { id = meeting.Id }, meeting);
        }
        catch (DbUpdateException ex)
        {
            _logger.LogError(ex, "Error saving meeting to the database.");
            return StatusCode(
                500,
                "An error occurred while saving the meeting. Please try again later."
            );
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error while creating meeting.");
            return StatusCode(500, "An unexpected error occurred. Please try again later.");
        }
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<Meeting>> GetMeeting(Guid id)
    {
        var meeting = await _context
            .Meetings.Include(m => m.Project)
            .FirstOrDefaultAsync(m => m.Id == id);

        return meeting == null ? NotFound() : meeting;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Meeting>>> GetMeetings()
    {
        return await _context.Meetings.Include(m => m.Project).ToListAsync();
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateMeeting(Guid id, [FromBody] MeetingDto dto)
    {
        var meeting = await _context
            .Meetings.Include(m => m.Project)
            .FirstOrDefaultAsync(m => m.Id == id);

        if (meeting == null)
        {
            _logger.LogWarning("UpdateMeeting: Meeting with ID {Id} not found.", id);
            return NotFound();
        }

        meeting.Date = dto.Date.ToUniversalTime();
        meeting.Location = dto.Location;
        meeting.Summary = dto.Summary;
        meeting.ResourceUrl = dto.ResourceUrl;
        meeting.ProjectId = dto.ProjectId;
        meeting.ParticipantCompanyIds = dto.ParticipantCompanyIds;

        var (isValid, errorMessage) = _validator.ValidateNewMeeting(meeting);
        if (!isValid)
        {
            _logger.LogWarning("UpdateMeeting: {Error}", errorMessage);
            return BadRequest(errorMessage);
        }

        var (referencesValid, referenceError) = await _validator.ValidateReferencesAsync(meeting);
        if (!referencesValid)
        {
            _logger.LogWarning("UpdateMeeting: {Error}", referenceError);
            return BadRequest(referenceError);
        }

        try
        {
            _context.Meetings.Update(meeting);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Meeting updated successfully with ID {Id}", id);
            return NoContent();
        }
        catch (DbUpdateException ex)
        {
            _logger.LogError(ex, "Error updating meeting in the database.");
            return StatusCode(
                500,
                "An error occurred while updating the meeting. Please try again later."
            );
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error while updating meeting.");
            return StatusCode(500, "An unexpected error occurred. Please try again later.");
        }
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteMeeting(Guid id)
    {
        var meeting = await _context.Meetings.FindAsync(id);
        if (meeting == null)
        {
            _logger.LogWarning("DeleteMeeting: Meeting with ID {Id} not found.", id);
            return NotFound();
        }

        try
        {
            _context.Meetings.Remove(meeting);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Meeting deleted successfully with ID {Id}", id);
            return NoContent();
        }
        catch (DbUpdateException ex)
        {
            _logger.LogError(ex, "Error deleting meeting from the database.");
            return StatusCode(
                500,
                "An error occurred while deleting the meeting. Please try again later."
            );
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error while deleting meeting.");
            return StatusCode(500, "An unexpected error occurred. Please try again later.");
        }
    }
}
