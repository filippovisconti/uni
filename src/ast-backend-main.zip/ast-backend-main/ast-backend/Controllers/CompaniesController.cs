using ast_backend.Models;
using ast_backend.Persistence;
using ast_backend.Services.Validation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ast_backend.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CompaniesController(
    AppDbContext context,
    ILogger<CompaniesController> logger,
    ICompanyValidator validator
) : ControllerBase
{
    private readonly AppDbContext _context = context;
    private readonly ILogger<CompaniesController> _logger = logger;
    private readonly ICompanyValidator _validator = validator;

    // GET: api/Companies
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Company>>> GetCompanies()
    {
        return await _context.Companies.Include(c => c.Address).ToListAsync();
    }

    // GET: api/Companies/{id}
    [HttpGet("{id}")]
    public async Task<ActionResult<Company>> GetCompany(Guid id)
    {
        try
        {
            var company = await _context
                .Companies.Include(c => c.Address)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (company == null)
                return NotFound();

            return company;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving company {CompanyId}", id);
            return StatusCode(500, "An error occurred while retrieving the company." + ex.Message);
        }
    }

    // POST: api/Companies

    [HttpPost]
    public async Task<ActionResult<Company>> CreateCompany(Company company)
    {
        company.Id = Guid.NewGuid();

        var (isValid, errorMsg) = await _validator.ValidateNewCompanyAsync(company);
        if (!isValid)
        {
            _logger.LogWarning("CreateCompany failed: {Error}", errorMsg);
            return BadRequest(errorMsg);
        }

        try
        {
            _context.Addresses.Add(company.Address);
            await _context.SaveChangesAsync();

            _context.Companies.Add(company);
            await _context.SaveChangesAsync();

            _logger.LogInformation(
                "Created company {CompanyName} with ID {CompanyId}",
                company.Name,
                company.Id
            );
            return CreatedAtAction(nameof(GetCompany), new { id = company.Id }, company);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating company.");
            return StatusCode(500, "An error occurred while creating the company.");
        }
    }

    // PUT: api/Companies/{id}
    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateCompany(Guid id, Company updated)
    {
        if (id != updated.Id)
            return BadRequest("ID mismatch");

        var existing = await _context
            .Companies.Include(c => c.Address)
            .FirstOrDefaultAsync(c => c.Id == id);
        if (existing == null)
        {
            _logger.LogWarning("UpdateCompany failed: Company {CompanyId} not found", id);
            return NotFound();
        }

        var (isValid, errorMsg) = await _validator.ValidateUpdateCompanyAsync(id, updated);
        if (!isValid)
        {
            _logger.LogWarning("UpdateCompany failed: {Error}", errorMsg);
            return BadRequest(errorMsg);
        }

        try
        {
            // Update address
            existing.Address.Street = updated.Address.Street;
            existing.Address.HouseNumber = updated.Address.HouseNumber;
            existing.Address.City = updated.Address.City;
            existing.Address.Province = updated.Address.Province;
            existing.Address.PostalCode = updated.Address.PostalCode;
            existing.Address.Country = updated.Address.Country;

            // Update company
            existing.Name = updated.Name;
            existing.ContactEmail = updated.ContactEmail;
            existing.ContactPhone = updated.ContactPhone;

            await _context.SaveChangesAsync();

            _logger.LogInformation("Updated company {CompanyId}", id);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating company {CompanyId}", id);
            return StatusCode(500, "An error occurred while updating the company.");
        }
    }

    // delete

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteCompany(Guid id)
    {
        var company = await _context.Companies.FindAsync(id);
        if (company == null)
        {
            _logger.LogWarning("DeleteCompany failed: Company {CompanyId} not found", id);
            return NotFound();
        }

        try
        {
            _context.Companies.Remove(company);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Deleted company {CompanyId}", id);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting company {CompanyId}", id);
            return StatusCode(500, "An error occurred while deleting the company.");
        }
    }
}
