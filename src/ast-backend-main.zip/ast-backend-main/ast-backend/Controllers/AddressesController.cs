using ast_backend.Models;
using ast_backend.Persistence;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ast_backend.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AddressesController(AppDbContext context) : ControllerBase
{
    private readonly AppDbContext _context = context;

    // GET: api/Addresses
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Address>>> GetAddresses()
    {
        return await _context.Addresses.ToListAsync();
    }

    // GET: api/Addresses/{id}
    [HttpGet("{id}")]
    public async Task<ActionResult<Address>> GetAddress(Guid id)
    {
        var address = await _context.Addresses.FindAsync(id);
        if (address == null)
        {
            return NotFound();
        }

        return address;
    }

    // POST: api/Addresses
    [HttpPost]
    public async Task<ActionResult<Address>> CreateAddress(Address address)
    {
        address.Id = Guid.NewGuid();
        _context.Addresses.Add(address);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetAddress), new { id = address.Id }, address);
    }

    // PUT: api/Addresses/{id}
    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateAddress(Guid id, Address updatedAddress)
    {
        if (id != updatedAddress.Id)
        {
            return BadRequest("ID mismatch.");
        }

        var existing = await _context.Addresses.FindAsync(id);
        if (existing == null)
        {
            return NotFound();
        }

        existing.Street = updatedAddress.Street;
        existing.HouseNumber = updatedAddress.HouseNumber;
        existing.City = updatedAddress.City;
        existing.Province = updatedAddress.Province;
        existing.PostalCode = updatedAddress.PostalCode;
        existing.Country = updatedAddress.Country;

        await _context.SaveChangesAsync();
        return NoContent();
    }

    // DELETE: api/Addresses/{id}
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteAddress(Guid id)
    {
        var address = await _context.Addresses.FindAsync(id);
        if (address == null)
        {
            return NotFound();
        }

        _context.Addresses.Remove(address);
        await _context.SaveChangesAsync();

        return NoContent();
    }
}
