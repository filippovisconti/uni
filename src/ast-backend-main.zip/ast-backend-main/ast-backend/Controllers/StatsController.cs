using ast_backend.DTOs;
using ast_backend.Persistence;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ast_backend.Controllers;

[ApiController]
[Route("api/[controller]")]
public class StatsController(AppDbContext context) : ControllerBase
{
    private readonly AppDbContext _context = context;

    [HttpGet]
    public async Task<ActionResult<StatsDto>> GetStats()
    {
        var stats = new StatsDto
        {
            TotalWorkItems = await _context.WorkItems.CountAsync(),
            TotalProjects = await _context.Projects.CountAsync(),
            TotalCompanies = await _context.Companies.CountAsync(),
            TotalLetters = await _context.Letters.CountAsync(),
            TotalMeetings = await _context.Meetings.CountAsync(),
            WorkItemsPerState = await _context
                .WorkItems.GroupBy(w => w.CurrentState)
                .Select(g => new { State = g.Key.ToString(), Count = g.Count() })
                .ToDictionaryAsync(x => x.State, x => x.Count),
        };

        return Ok(stats);
    }
}
