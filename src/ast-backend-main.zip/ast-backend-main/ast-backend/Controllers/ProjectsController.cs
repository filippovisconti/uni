using ast_backend.Models;
using ast_backend.Persistence;
using ast_backend.Services.Validation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ast_backend.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProjectsController(
    AppDbContext context,
    ILogger<ProjectsController> logger,
    IProjectValidator validator
) : ControllerBase
{
    private readonly AppDbContext _context = context;
    private readonly ILogger<ProjectsController> _logger = logger;
    private readonly IProjectValidator _validator = validator;

    // GET: api/Projects
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Project>>> GetProjects()
    {
        return await _context.Projects.ToListAsync();
    }

    // GET: api/Projects/{id}

    [HttpGet("{id}")]
    public async Task<ActionResult<Project>> GetProject(Guid id)
    {
        var project = await _context.Projects.FindAsync(id);
        if (project == null)
            return NotFound();

        return project;
    }

    // POST: api/Projects
    [HttpPost]
    public async Task<ActionResult<Project>> CreateProject(Project project)
    {
        project.Id = Guid.NewGuid();

        var (isValid, error) = await _validator.ValidateAsync(project);
        if (!isValid)
        {
            _logger.LogWarning("Project creation failed: {Error}", error);
            return BadRequest(error);
        }

        try
        {
            _context.Projects.Add(project);
            await _context.SaveChangesAsync();
            _logger.LogInformation("Project {ProjectId} created.", project.Id);

            return CreatedAtAction(nameof(GetProject), new { id = project.Id }, project);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating project");
            return StatusCode(500, "An error occurred while creating the project.");
        }
    }

    // PUT: api/Projects/{id}
    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateProject(Guid id, Project updated)
    {
        if (id != updated.Id)
            // use format string interpolation for better readability
            return BadRequest("ID mismatch. Expected: " + id + ", Received: " + updated.Id);

        var existing = await _context.Projects.FindAsync(id);
        if (existing == null)
            return NotFound();

        var (isValid, error) = await _validator.ValidateAsync(updated);
        if (!isValid)
        {
            _logger.LogWarning("Project update failed: {Error}", error);
            return BadRequest(error);
        }

        try
        {
            existing.Name = updated.Name;
            existing.Description = updated.Description;
            await _context.SaveChangesAsync();
            _logger.LogInformation("Project {ProjectId} updated.", id);

            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating project {ProjectId}", id);
            return StatusCode(500, "An error occurred while updating the project.");
        }
    }

    // DELETE: api/Projects/{id}
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteProject(Guid id)
    {
        var project = await _context.Projects.FindAsync(id);
        if (project is null)
            return NotFound();

        _context.Projects.Remove(project);
        await _context.SaveChangesAsync();

        return NoContent();
    }
}
