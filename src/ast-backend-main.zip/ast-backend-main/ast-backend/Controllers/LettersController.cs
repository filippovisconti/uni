using ast_backend.DTOs;
using ast_backend.Models;
using ast_backend.Persistence;
using ast_backend.Services.Validation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ast_backend.Controllers;

[ApiController]
[Route("api/[controller]")]
public class LettersController(
    AppDbContext context,
    ILogger<LettersController> logger,
    ILetterValidator validator
) : ControllerBase
{
    private readonly AppDbContext _context = context;
    private readonly ILogger<LettersController> _logger = logger;
    private readonly ILetterValidator _validator = validator;

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Letter>>> GetLetters(
        [FromQuery] string? protocolNumber,
        [FromQuery] string? subject,
        [FromQuery] DateTime? dateFrom,
        [FromQuery] DateTime? dateTo
    )
    {
        var query = _context
            .Letters.Include(l => l.Sender)
            .ThenInclude(c => c.Address)
            .AsQueryable();

        // String filters
        if (!string.IsNullOrWhiteSpace(protocolNumber))
        {
            query = query.Where(l =>
                l.ProtocolNumber.Contains(protocolNumber)
                || (
                    l.SenderProtocolNumber != null
                    && l.SenderProtocolNumber.Contains(protocolNumber)
                )
            );
        }

        if (!string.IsNullOrWhiteSpace(subject))
        {
            query = query.Where(l => l.Subject.Contains(subject));
        }

        // Date range filter with OR logic
        if (dateFrom.HasValue || dateTo.HasValue)
        {
            query = query.Where(l =>
                (
                    (dateFrom == null || l.ProtocolDate >= dateFrom)
                    && (dateTo == null || l.ProtocolDate <= dateTo)
                )
                || (
                    (dateFrom == null || l.SenderProtocolDate >= dateFrom)
                    && (dateTo == null || l.SenderProtocolDate <= dateTo)
                )
                || (
                    (dateFrom == null || l.ReceivedDate >= dateFrom)
                    && (dateTo == null || l.ReceivedDate <= dateTo)
                )
            );
        }

        var letters = await query.ToListAsync();
        return Ok(letters);
    }

    // GET: api/Letters/{id}
    [HttpGet("{id}")]
    public async Task<ActionResult<Letter>> GetLetter(Guid id)
    {
        var letter = await _context
            .Letters.Include(l => l.Sender)
            .ThenInclude(c => c.Address)
            .FirstOrDefaultAsync(l => l.Id == id);

        return letter is null ? NotFound() : letter;
    }

    // POST: api/Letters
    [HttpPost]
    public async Task<ActionResult<Letter>> CreateLetter([FromBody] LetterDto dto)
    {
        var (isValid, errorMessage) = await _validator.ValidateReferencesAsync(dto.SenderId);
        if (!isValid)
        {
            _logger.LogWarning("CreateLetter: {Error}", errorMessage);
            return BadRequest(errorMessage);
        }

        try
        {
            var sender = await _context.Companies.FindAsync(dto.SenderId);

            var letter = new Letter
            {
                Id = Guid.NewGuid(),
                ProtocolNumber = dto.ProtocolNumber,
                ProtocolDate = dto.ProtocolDate,
                Sender = sender!,
                SenderProtocolNumber = dto.SenderProtocolNumber,
                SenderProtocolDate = dto.SenderProtocolDate,
                Subject = dto.Subject,
                Body = dto.Body,
                ReceivedDate = dto.ReceivedDate,
                AttachmentBundleLink = dto.AttachmentBundleLink,
            };

            _context.Letters.Add(letter);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Letter {LetterId} created successfully.", letter.Id);
            return CreatedAtAction(nameof(GetLetter), new { id = letter.Id }, letter);
        }
        catch (DbUpdateException dbEx)
        {
            _logger.LogError(dbEx, "Database error while creating letter.");
            return StatusCode(500, "Database error. Check your data and try again.");
        }
        catch (Exception ex)
        {
            _logger.LogCritical(ex, "Unexpected error while creating letter.");
            return StatusCode(500, "Unexpected error while creating letter.");
        }
    }

    // PUT: api/Letters/{id}
    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateLetter(Guid id, [FromBody] LetterDto dto)
    {
        var letter = await _context
            .Letters.Include(l => l.Sender)
            .FirstOrDefaultAsync(l => l.Id == id);
        if (letter == null)
        {
            _logger.LogWarning("UpdateLetter: Letter with ID {LetterId} not found.", id);
            return NotFound();
        }

        var (isValid, errorMessage) = await _validator.ValidateReferencesAsync(dto.SenderId);
        if (!isValid)
        {
            _logger.LogWarning("UpdateLetter: {Error}", errorMessage);
            return BadRequest(errorMessage);
        }

        try
        {
            var sender = await _context.Companies.FindAsync(dto.SenderId);

            letter.ProtocolNumber = dto.ProtocolNumber;
            letter.ProtocolDate = dto.ProtocolDate;
            letter.Sender = sender!;
            letter.SenderProtocolNumber = dto.SenderProtocolNumber;
            letter.SenderProtocolDate = dto.SenderProtocolDate;
            letter.Subject = dto.Subject;
            letter.Body = dto.Body;
            letter.ReceivedDate = dto.ReceivedDate;
            letter.AttachmentBundleLink = dto.AttachmentBundleLink;

            await _context.SaveChangesAsync();
            _logger.LogInformation("Letter {LetterId} updated successfully.", id);
            return NoContent();
        }
        catch (DbUpdateException dbEx)
        {
            _logger.LogError(dbEx, "Database error while updating letter {LetterId}.", id);
            return StatusCode(500, "Database update failed.");
        }
        catch (Exception ex)
        {
            _logger.LogCritical(ex, "Unexpected error while updating letter {LetterId}.", id);
            return StatusCode(500, "Unexpected error occurred.");
        }
    }

    // DELETE: api/Letters/{id}
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteLetter(Guid id)
    {
        var letter = await _context.Letters.FindAsync(id);
        if (letter is null)
            return NotFound();

        _context.Letters.Remove(letter);
        await _context.SaveChangesAsync();

        return NoContent();
    }
}
