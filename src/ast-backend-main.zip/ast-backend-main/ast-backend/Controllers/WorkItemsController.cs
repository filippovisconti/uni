using System.ComponentModel.DataAnnotations;
using ast_backend.DTOs;
using ast_backend.Models;
using ast_backend.Persistence;
using ast_backend.Services.Validation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ast_backend.Controllers;

[ApiController]
[Route("api/[controller]")]
public class WorkItemsController(
    AppDbContext context,
    ILogger<WorkItemsController> logger,
    IWorkItemValidator validator
) : ControllerBase
{
    private readonly AppDbContext _context = context;
    private readonly ILogger<WorkItemsController> _logger = logger;
    private readonly IWorkItemValidator _validator = validator;

    [HttpGet("{id}")]
    public async Task<ActionResult<WorkItem>> GetWorkItem(Guid id)
    {
        var item = await _context.WorkItems.FindAsync(id);
        return item == null ? (ActionResult<WorkItem>)NotFound() : (ActionResult<WorkItem>)item;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<WorkItem>>> GetWorkItems(
        [FromQuery] Guid? assigneeId,
        [FromQuery] Guid? projectId,
        [FromQuery] Guid? companyId,
        [FromQuery] int? state
    )
    {
        var query = _context
            .WorkItems.Include(w => w.Letter)
            .ThenInclude(l => l!.Sender)
            .Include(w => w.Project)
            .Include(w => w.Assignee)
            .Include(w => w.AssignedBy)
            .AsQueryable();

        if (assigneeId.HasValue)
        {
            query = query.Where(w => w.AssigneeId == assigneeId.Value);
        }

        if (projectId.HasValue)
        {
            query = query.Where(w => w.ProjectId == projectId.Value);
        }

        if (companyId.HasValue)
        {
            query = query.Where(w =>
                w.Letter != null && w.Letter.Sender != null && w.Letter.Sender.Id == companyId.Value
            );
        }

        if (state.HasValue)
        {
            query = query.Where(w => (int)w.CurrentState == state.Value);
        }

        var workItems = await query.ToListAsync();

        foreach (var w in workItems)
        {
            // Fallback populate if navigation properties are still null
            if (w.Letter == null)
            {
                w.Letter = await _context
                    .Letters.Include(l => l.Sender)
                    .FirstOrDefaultAsync(l => l.Id == w.LetterId);
            }

            if (w.Project == null && w.ProjectId != null)
            {
                w.Project = await _context.Projects.FirstOrDefaultAsync(p => p.Id == w.ProjectId);
            }

            if (w.Assignee == null)
            {
                w.Assignee = await _context.Users.FirstOrDefaultAsync(u => u.Id == w.AssigneeId);
            }

            if (w.AssignedBy == null)
            {
                w.AssignedBy = await _context.Users.FirstOrDefaultAsync(u =>
                    u.Id == w.AssignedById
                );
            }
        }

        return Ok(workItems);
    }

    [HttpPost]
    public async Task<ActionResult<WorkItem>> CreateWorkItem(CreateWorkItemDto dto)
    {
        var workItem = new WorkItem
        {
            Id = Guid.NewGuid(),
            CreationDate = dto.CreationDate ?? DateTime.UtcNow,
            CurrentState = dto.CurrentState,
            ArchivalDate = dto.ArchivalDate,
            AssignmentDate = dto.AssignmentDate,
            AssignmentNotes = dto.AssignmentNotes,
            AssigneeId = dto.AssigneeId,
            AssignedById = dto.AssignedById,
            LetterId = dto.LetterId,
            ProjectId = dto.ProjectId,
        };

        // Validate foreign keys using central validator
        var (isValid, errorMsg) = await _validator.ValidateReferencesAsync(workItem);
        if (!isValid)
        {
            _logger.LogWarning("CreateWorkItem: FK validation failed - {Error}", errorMsg);
            return BadRequest(errorMsg);
        }

        try
        {
            _context.WorkItems.Add(workItem);
            await _context.SaveChangesAsync();
            _logger.LogInformation("WorkItem {WorkItemId} created successfully.", workItem.Id);
            return CreatedAtAction(nameof(GetWorkItem), new { id = workItem.Id }, workItem);
        }
        catch (DbUpdateException dbEx)
        {
            _logger.LogError(dbEx, "Database update failed while creating WorkItem.");
            return StatusCode(500, "Database update error. Please check your data and try again.");
        }
        catch (ValidationException valEx)
        {
            _logger.LogWarning(valEx, "Validation failed while creating WorkItem.");
            return BadRequest($"Validation error: {valEx.Message}");
        }
        catch (Exception ex)
        {
            _logger.LogCritical(ex, "Unexpected error while creating WorkItem.");
            return StatusCode(500, "An unexpected error occurred while creating the WorkItem.");
        }
    }

    // PUT: api/WorkItems/{id}
    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateWorkItem(Guid id, WorkItem updatedItem)
    {
        if (id != updatedItem.Id)
        {
            _logger.LogWarning(
                "UpdateWorkItem: ID mismatch (route: {RouteId}, payload: {PayloadId})",
                id,
                updatedItem.Id
            );
            return BadRequest("ID mismatch between route and payload.");
        }

        var existingItem = await _context.WorkItems.FindAsync(id);
        if (existingItem == null)
        {
            _logger.LogWarning("UpdateWorkItem: WorkItem with ID {WorkItemId} not found.", id);
            return NotFound();
        }

        // Validate references
        var (isValid, errorMsg) = await _validator.ValidateReferencesAsync(updatedItem);
        if (!isValid)
        {
            _logger.LogWarning(
                "UpdateWorkItem: FK validation failed for WorkItem {WorkItemId} - {Error}",
                id,
                errorMsg
            );
            return BadRequest(errorMsg);
        }

        // Apply updates...
        existingItem.AssignmentDate = updatedItem.AssignmentDate;
        existingItem.AssignmentNotes = updatedItem.AssignmentNotes;
        existingItem.CurrentState = updatedItem.CurrentState;
        existingItem.ArchivalDate = updatedItem.ArchivalDate;
        existingItem.AssigneeId = updatedItem.AssigneeId;
        existingItem.AssignedById = updatedItem.AssignedById;
        existingItem.ProjectId = updatedItem.ProjectId;
        existingItem.LetterId = updatedItem.LetterId;

        try
        {
            await _context.SaveChangesAsync();
            _logger.LogInformation("WorkItem {WorkItemId} updated successfully.", id);
            return NoContent();
        }
        catch (DbUpdateException dbEx)
        {
            _logger.LogError(dbEx, "Database update failed for WorkItem {WorkItemId}.", id);
            return StatusCode(500, "Failed to update WorkItem due to a database error.");
        }
        catch (ValidationException valEx)
        {
            _logger.LogWarning(
                valEx,
                "Validation failed while updating WorkItem {WorkItemId}.",
                id
            );
            return BadRequest($"Validation error: {valEx.Message}");
        }
        catch (Exception ex)
        {
            _logger.LogCritical(
                ex,
                "Unexpected error occurred while updating WorkItem {WorkItemId}.",
                id
            );
            return StatusCode(500, "An unexpected error occurred while updating the WorkItem.");
        }
    }

    // DELETE: api/WorkItems/{id}
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteWorkItem(Guid id)
    {
        var item = await _context.WorkItems.FindAsync(id);
        if (item == null)
        {
            return NotFound();
        }

        _context.WorkItems.Remove(item);
        await _context.SaveChangesAsync();

        return NoContent();
    }
}
