// Program.cs

using ast_backend.Persistence;
using ast_backend.Services.Validation;
using DotNetEnv;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

if (builder.Environment.IsDevelopment())
{
    Env.Load();
}

string GetEnvVar(string key) =>
    builder.Configuration[key]
    ?? Environment.GetEnvironmentVariable(key)
    ?? throw new InvalidOperationException($"Missing configuration for {key}");

// Build connection string from environment variables
var connectionString = new Npgsql.NpgsqlConnectionStringBuilder
{
    Host = GetEnvVar("DB_HOST"),
    Port = int.Parse(GetEnvVar("DB_PORT")),
    Database = GetEnvVar("DB_NAME"),
    Username = GetEnvVar("DB_USER"),
    Password = GetEnvVar("DB_PASSWORD"),
    // Optionally add other parameters for SSL, pooling, timeouts, etc.
}.ToString();
builder.Services.AddDbContext<AppDbContext>(options => options.UseNpgsql(connectionString));

// Add services to the container.
builder.Services.AddControllers();

// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();
builder.Services.AddScoped<IWorkItemValidator, WorkItemValidator>();
builder.Services.AddScoped<ILetterValidator, LetterValidator>();
builder.Services.AddScoped<ICompanyValidator, CompanyValidator>();
builder.Services.AddScoped<IProjectValidator, ProjectValidator>();
builder.Services.AddScoped<IMeetingValidator, MeetingValidator>();
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader();
    });
});
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.UseSwaggerUi(options =>
    {
        options.DocumentPath = "/openapi/v1.json";
    });
}

app.UseCors();

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
