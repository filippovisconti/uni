﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ast_backend.Migrations
{
    /// <inheritdoc />
    public partial class update1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_WorkItems_Companies_SenderId",
                table: "WorkItems");

            migrationBuilder.DropForeignKey(
                name: "FK_WorkItems_Letters_LetterId",
                table: "WorkItems");

            migrationBuilder.DropIndex(
                name: "IX_WorkItems_SenderId",
                table: "WorkItems");

            migrationBuilder.DropColumn(
                name: "MailId",
                table: "WorkItems");

            migrationBuilder.DropColumn(
                name: "SenderId",
                table: "WorkItems");

            migrationBuilder.AlterColumn<Guid>(
                name: "LetterId",
                table: "WorkItems",
                type: "uuid",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"),
                oldClrType: typeof(Guid),
                oldType: "uuid",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_WorkItems_Letters_LetterId",
                table: "WorkItems",
                column: "LetterId",
                principalTable: "Letters",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_WorkItems_Letters_LetterId",
                table: "WorkItems");

            migrationBuilder.AlterColumn<Guid>(
                name: "LetterId",
                table: "WorkItems",
                type: "uuid",
                nullable: true,
                oldClrType: typeof(Guid),
                oldType: "uuid");

            migrationBuilder.AddColumn<Guid>(
                name: "MailId",
                table: "WorkItems",
                type: "uuid",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "SenderId",
                table: "WorkItems",
                type: "uuid",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.CreateIndex(
                name: "IX_WorkItems_SenderId",
                table: "WorkItems",
                column: "SenderId");

            migrationBuilder.AddForeignKey(
                name: "FK_WorkItems_Companies_SenderId",
                table: "WorkItems",
                column: "SenderId",
                principalTable: "Companies",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_WorkItems_Letters_LetterId",
                table: "WorkItems",
                column: "LetterId",
                principalTable: "Letters",
                principalColumn: "Id");
        }
    }
}
