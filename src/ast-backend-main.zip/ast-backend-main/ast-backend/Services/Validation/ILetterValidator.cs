namespace ast_backend.Services.Validation;

public interface ILetterValidator
{
    Task<(bool IsValid, string? ErrorMessage)> ValidateReferencesAsync(Guid senderId);
}
