using ast_backend.Models;
using ast_backend.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ast_backend.Services.Validation;

public class MeetingValidator(AppDbContext context) : IMeetingValidator
{
    private readonly AppDbContext _context = context;

    public (bool IsValid, string? ErrorMessage) ValidateNewMeeting(Meeting meeting)
    {
        if (meeting == null)
        {
            return (false, "Meeting cannot be null.");
        }

        if (meeting.Date == default)
        {
            return (false, "Meeting date must be specified.");
        }

        if (meeting.Date > DateTime.UtcNow)
        {
            return (false, "Meeting date cannot be in the future.");
        }

        if (string.IsNullOrWhiteSpace(meeting.Location))
        {
            return (false, "Meeting location cannot be empty.");
        }

        if (meeting.ProjectId == Guid.Empty)
        {
            return (false, "Meeting must be associated with a valid project.");
        }
        if (meeting.ParticipantCompanyIds == null || meeting.ParticipantCompanyIds.Count == 0)
        {
            return (false, "Meeting must have at least one participant company.");
        }

        if (string.IsNullOrWhiteSpace(meeting.Summary))
        {
            return (false, "Meeting subject cannot be empty.");
        }

        return (true, null);
    }

    public async Task<(bool IsValid, string? ErrorMessage)> ValidateReferencesAsync(Meeting meeting)
    {
        if (meeting.ParticipantCompanyIds == null)
        {
            return (false, "Participant company IDs cannot be null.");
        }
        foreach (var companyId in meeting.ParticipantCompanyIds)
        {
            if (companyId == Guid.Empty)
            {
                return (false, "Participant company ID cannot be empty.");
            }

            var exists = await _context.Companies.AnyAsync(c => c.Id == companyId);
            if (!exists)
            {
                return (false, $"Company with ID {companyId} does not exist.");
            }
        }

        return (true, null);
    }
}
