// Services/Validation/IWorkItemValidator.cs

// Services/Validation/IWorkItemValidator.cs
using ast_backend.Models;

namespace ast_backend.Services.Validation;

public interface IWorkItemValidator
{
    Task<(bool IsValid, string? ErrorMessage)> ValidateReferencesAsync(WorkItem item);
}
