using ast_backend.Models;
using ast_backend.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ast_backend.Services.Validation;

public class CompanyValidator(AppDbContext context) : ICompanyValidator
{
    private readonly AppDbContext _context = context;

    public async Task<(bool IsValid, string? ErrorMessage)> ValidateNewCompanyAsync(Company company)
    {
        if (await _context.Companies.AnyAsync(c => EF.Functions.ILike(c.Name, company.Name)))
        {
            return (false, $"Company with name '{company.Name}' already exists.");
        }

        return (true, null);
    }

    public async Task<(bool IsValid, string? ErrorMessage)> ValidateUpdateCompanyAsync(
        Guid id,
        Company updatedCompany
    )
    {
        if (
            await _context.Companies.AnyAsync(c =>
                c.Id != id && EF.Functions.ILike(c.Name, updatedCompany.Name)
            )
        )
        {
            return (false, $"Another company with name '{updatedCompany.Name}' already exists.");
        }

        return (true, null);
    }
}
