using ast_backend.Models;

namespace ast_backend.Services.Validation;

public interface ICompanyValidator
{
    Task<(bool IsValid, string? ErrorMessage)> ValidateNewCompanyAsync(Company company);
    Task<(bool IsValid, string? ErrorMessage)> ValidateUpdateCompanyAsync(
        Guid id,
        Company updatedCompany
    );
}
