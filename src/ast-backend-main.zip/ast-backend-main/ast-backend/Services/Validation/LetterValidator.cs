using ast_backend.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ast_backend.Services.Validation;

public class LetterValidator(AppDbContext context) : ILetterValidator
{
    private readonly AppDbContext _context = context;

    public async Task<(bool IsValid, string? ErrorMessage)> ValidateReferencesAsync(Guid senderId)
    {
        if (!await _context.Companies.AnyAsync(c => c.Id == senderId))
            return (false, "Invalid sender ID");

        return (true, null);
    }
}
