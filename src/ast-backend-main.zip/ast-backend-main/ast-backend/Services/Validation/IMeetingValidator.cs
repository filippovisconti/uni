using ast_backend.Models;

namespace ast_backend.Services.Validation;

public interface IMeetingValidator
{
    (bool IsValid, string? ErrorMessage) ValidateNewMeeting(Meeting meeting);
    Task<(bool IsValid, string? ErrorMessage)> ValidateReferencesAsync(Meeting meeting);
}
