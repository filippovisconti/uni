// Services/Validation/WorkItemValidator.cs
using ast_backend.Models;
using ast_backend.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ast_backend.Services.Validation;

public class WorkItemValidator(AppDbContext context) : IWorkItemValidator
{
    private readonly AppDbContext _context = context;

    public async Task<(bool IsValid, string? ErrorMessage)> ValidateReferencesAsync(WorkItem item)
    {
        if (!await _context.Users.AnyAsync(u => u.Id == item.AssigneeId))
            return (false, "Assignee does not exist.");

        if (!await _context.Users.AnyAsync(u => u.Id == item.AssignedById))
            return (false, "AssignedBy does not exist.");

        if (!await _context.Letters.AnyAsync(l => l.Id == item.LetterId))
            return (false, "Letter does not exist.");

        if (
            item.ProjectId is not null
            && !await _context.Projects.AnyAsync(p => p.Id == item.ProjectId)
        )
            return (false, "Project does not exist.");

        var duplicateExists = await _context.WorkItems.AnyAsync(w =>
            w.Id != item.Id && w.LetterId == item.LetterId && w.ProjectId == item.ProjectId
        );

        if (duplicateExists)
        {
            return (false, "A work item with the same Letter and Project already exists.");
        }
        return (true, null);
    }
}
