using ast_backend.Models;
using ast_backend.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ast_backend.Services.Validation;

public class ProjectValidator : IProjectValidator
{
    private readonly AppDbContext _context;

    public ProjectValidator(AppDbContext context)
    {
        _context = context;
    }

    public async Task<(bool IsValid, string? ErrorMessage)> ValidateAsync(Project project)
    {
        if (string.IsNullOrWhiteSpace(project.Name))
            return (false, "Project name is required.");

        var duplicateExists = await _context.Projects.AnyAsync(p =>
            p.Id != project.Id && p.Name.ToLower() == project.Name.ToLower()
        );

        if (duplicateExists)
            return (false, "A project with the same name already exists.");

        return (true, null);
    }
}
