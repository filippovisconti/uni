using ast_backend.Models;

namespace ast_backend.Services.Validation;

public interface IProjectValidator
{
    Task<(bool IsValid, string? ErrorMessage)> ValidateAsync(Project project);
}
