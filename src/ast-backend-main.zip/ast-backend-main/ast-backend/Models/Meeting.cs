using System.ComponentModel.DataAnnotations;

namespace ast_backend.Models;

public class Meeting
{
    [Key]
    public Guid Id { get; set; }

    [Required]
    public DateTime Date { get; set; }

    [Required]
    [StringLength(255)]
    public string Location { get; set; } = string.Empty;

    [StringLength(500)]
    public string? Summary { get; set; }

    [Url]
    public string? ResourceUrl { get; set; }

    [Required]
    public Guid ProjectId { get; set; }
    public Project? Project { get; set; } = null;

    // Store company IDs directly (denormalized)
    [Required]
    public List<Guid> ParticipantCompanyIds { get; set; } = new();
}
