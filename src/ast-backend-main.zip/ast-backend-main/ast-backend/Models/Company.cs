using System.ComponentModel.DataAnnotations;

namespace ast_backend.Models;

public class Company
{
    [Key]
    public Guid Id { get; set; } = Guid.NewGuid();

    public required string Name { get; set; }

    public required Address Address { get; set; }

    public string? ContactEmail { get; set; }

    public string? ContactPhone { get; set; }
}
