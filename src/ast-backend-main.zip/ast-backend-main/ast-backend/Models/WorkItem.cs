using System.ComponentModel.DataAnnotations;

namespace ast_backend.Models;

public enum WorkItemState
{
    NotAssigned,
    InProgress,
    WaitingForApproval,
    Closed,
    Archived,
}

public class WorkItem
{
    [Key]
    public Guid Id { get; set; }

    public DateTime CreationDate { get; set; } = DateTime.UtcNow;

    public WorkItemState CurrentState { get; set; } = WorkItemState.NotAssigned;

    public DateTime? ArchivalDate { get; set; }

    public DateTime AssignmentDate { get; set; }

    public required string AssignmentNotes { get; set; }

    [Required]
    public Guid AssigneeId { get; set; }
    public User? Assignee { get; set; }

    [Required]
    public Guid AssignedById { get; set; }
    public User? AssignedBy { get; set; }

    [Required]
    public Guid LetterId { get; set; }
    public Letter? Letter { get; set; }

    public Guid? ProjectId { get; set; }
    public Project? Project { get; set; }
}
