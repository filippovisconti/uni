using System.ComponentModel.DataAnnotations;

namespace ast_backend.Models;

public class User
{
    [Key]
    public Guid Id { get; set; }

    public required string FirstName { get; set; }
    public required string LastName { get; set; }
    public required string? Nickname { get; set; }
}
