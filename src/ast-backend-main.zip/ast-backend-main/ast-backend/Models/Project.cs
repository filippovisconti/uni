using System.ComponentModel.DataAnnotations;

namespace ast_backend.Models;

public class Project
{
    [Key]
    public Guid Id { get; set; }

    public required string Name { get; set; }

    public string? Description { get; set; }
}
