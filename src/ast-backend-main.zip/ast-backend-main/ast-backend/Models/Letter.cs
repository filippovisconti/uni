using System.ComponentModel.DataAnnotations;

namespace ast_backend.Models;

public class Letter
{
    [Key]
    public Guid Id { get; set; } = Guid.NewGuid();

    public required string ProtocolNumber { get; set; }

    [DataType(DataType.Date)]
    public required DateTime? ProtocolDate { get; set; }

    public required Company Sender { get; set; }

    public string? SenderProtocolNumber { get; set; }

    [DataType(DataType.Date)]
    public DateTime? SenderProtocolDate { get; set; }

    public required string Subject { get; set; }

    public required string Body { get; set; }

    [DataType(DataType.Date)]
    public required DateTime ReceivedDate { get; set; }

    public Uri? AttachmentBundleLink { get; set; }
}
