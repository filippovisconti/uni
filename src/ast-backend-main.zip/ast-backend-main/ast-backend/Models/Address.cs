using System.ComponentModel.DataAnnotations;

namespace ast_backend.Models;

public class Address
{
    [Key]
    public Guid Id { get; set; } = Guid.NewGuid();

    public required string Street { get; set; }
    public required string HouseNumber { get; set; }
    public required string City { get; set; }
    public required string Province { get; set; }
    public required string PostalCode { get; set; }
    public required string Country { get; set; }
}
