using ast_backend.Models;
using Microsoft.EntityFrameworkCore;

namespace ast_backend.Persistence;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<WorkItem> WorkItems { get; set; }
    public DbSet<Letter> Letters { get; set; }
    public DbSet<User> Users { get; set; }
    public DbSet<Project> Projects { get; set; }
    public DbSet<Company> Companies { get; set; }
    public DbSet<Address> Addresses { get; set; }
    public DbSet<Meeting> Meetings { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .Entity<WorkItem>()
            .HasOne(w => w.Assignee)
            .WithMany()
            .HasForeignKey(w => w.AssigneeId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder
            .Entity<WorkItem>()
            .HasOne(w => w.AssignedBy)
            .WithMany()
            .HasForeignKey(w => w.AssignedById)
            .OnDelete(DeleteBehavior.Restrict);
        modelBuilder
            .Entity<Meeting>()
            .Property(m => m.ParticipantCompanyIds)
            .HasConversion(
                v => string.Join(",", v),
                v => v.Split(",", StringSplitOptions.RemoveEmptyEntries).Select(Guid.Parse).ToList()
            );
    }
}
