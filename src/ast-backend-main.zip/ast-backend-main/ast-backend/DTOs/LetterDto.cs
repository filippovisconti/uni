using System.ComponentModel.DataAnnotations;

namespace ast_backend.DTOs;

public class LetterDto
{
    [Required]
    public string ProtocolNumber { get; set; } = null!;

    public DateTime? ProtocolDate { get; set; }

    [Required]
    public Guid SenderId { get; set; }

    public string? SenderProtocolNumber { get; set; }

    public DateTime? SenderProtocolDate { get; set; }

    [Required]
    public string Subject { get; set; } = null!;

    [Required]
    public string Body { get; set; } = null!;

    [Required]
    public DateTime ReceivedDate { get; set; }

    public Uri? AttachmentBundleLink { get; set; }
}
