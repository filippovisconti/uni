using System.ComponentModel.DataAnnotations;
using ast_backend.Models;

namespace ast_backend.DTOs;

public class CreateWorkItemDto
{
    // No Id here, it will be generated on creation

    public DateTime? CreationDate { get; set; } = null; // optional, default in entity

    public WorkItemState CurrentState { get; set; } = WorkItemState.NotAssigned;

    public DateTime? ArchivalDate { get; set; }

    [Required]
    public DateTime AssignmentDate { get; set; }

    [Required]
    [StringLength(1000)]
    public string AssignmentNotes { get; set; } = null!;

    [Required]
    public Guid AssigneeId { get; set; }

    [Required]
    public Guid AssignedById { get; set; }

    [Required]
    public Guid LetterId { get; set; }

    public Guid? ProjectId { get; set; }
}
