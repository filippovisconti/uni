using System.ComponentModel.DataAnnotations;
using ast_backend.Models;

namespace ast_backend.DTOs;

public class MeetingDto
{
    public DateTime Date { get; set; }

    [Required]
    [StringLength(255)]
    public string Location { get; set; } = string.Empty;

    [StringLength(500)]
    public string? Summary { get; set; }

    [Url]
    public string? ResourceUrl { get; set; }

    [Required]
    public Guid ProjectId { get; set; }

    public Project? Project { get; set; } = null;

    [Required]
    public List<Guid> ParticipantCompanyIds { get; set; } = [];
}
