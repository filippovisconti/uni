namespace ast_backend.DTOs;

public class StatsDto
{
    public int TotalWorkItems { get; set; }
    public Dictionary<string, int> WorkItemsPerState { get; set; } = [];
    public int TotalProjects { get; set; }
    public int TotalCompanies { get; set; }
    public int TotalLetters { get; set; }
    public int TotalMeetings { get; set; }
}
